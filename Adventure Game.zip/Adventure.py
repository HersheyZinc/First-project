import arcade
from Rooms import map
import math
import random

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 600

LEFT_FACING, RIGHT_FACING = 0, 1
SPRITE_SCALING_PLAYER = 0.4
SPRITE_SCALING_STONEWALL, SPRITE_SCALING_ROCK = 0.1, 0.5
SPRITE_SCALING_MAGE, SPRITE_SCALING_SOLDIER = 1, 1
SPRITE_SCALING_HEART = 0.25
SPRITE_SCALING_FIREBALL, FIREBALL_SPEED = 0.7, 2
SPRITE_SCALING_SIGN, SPRITE_SCALING_GRAVE = 1, 1



class Player(arcade.Sprite):
    def __init__(self):
        super().__init__()

        self.dead_textures = [arcade.load_texture("Player_Dead.png")]

        self.move1_texture_pair = [arcade.load_texture("Player_Move1.png", mirrored=True), arcade.load_texture("Player_Move1.png")]
        self.move2_texture_pair = [arcade.load_texture("Player_Move2.png", mirrored=True), arcade.load_texture("Player_Move2.png")]
        self.move_up_texture_pair = [arcade.load_texture("Player_FaceUp.png", mirrored=True), arcade.load_texture("Player_FaceUp.png")]
        self.move_down_texture_pair = [arcade.load_texture("Player_Stand.png", mirrored=True), arcade.load_texture("Player_Stand.png")]
        self.idle_texture_pair = [arcade.load_texture("Player_Stand.png", mirrored=True), arcade.load_texture("Player_Stand.png")]

        self.x_movement_textures = [self.move1_texture_pair, self.move2_texture_pair]
        self.y_movement_textures = [self.move_up_texture_pair, self.move_down_texture_pair]

        self.scale = SPRITE_SCALING_PLAYER
        self.character_face_direction = RIGHT_FACING
        self.texture = self.dead_textures[0]

        self.texture_state = 1



    def update(self, left, right, up, down, room_coords):
        self.center_y += self.change_y
        self.center_x += self.change_x
        max_speed = lambda speed: max(min(self.speed_limit, speed), -self.speed_limit)

        if left == True:
            self.change_x = max_speed(self.change_x - self.acceleration)
        if right == True:
            self.change_x = max_speed(self.change_x + self.acceleration)
        if right == True and left == True:
            self.change_x *= 0.8

        if down == True:
            self.change_y = max_speed(self.change_y - self.acceleration)
        if up == True:
            self.change_y = max_speed(self.change_y + self.acceleration)
        if up == True and down == True:
            self.change_y *= 0.8

        if up == False and down == False and self.change_y != 0:
            self.change_y *= 0.9
            if abs(self.change_y) < 0.3: self.change_y = 0
        if left == False and right == False and self.change_x != 0:
            self.change_x *= 0.9
            if abs(self.change_x) < 0.3: self.change_x = 0

    def update_facing(self):
        if self.change_x < 0 and self.character_face_direction == RIGHT_FACING:
            self.character_face_direction = LEFT_FACING
        elif self.change_x > 0 and self.character_face_direction == LEFT_FACING:
            self.character_face_direction = RIGHT_FACING

        if self.change_x != 0 and abs(self.change_x) > abs(self.change_y):
            self.texture = self.x_movement_textures[self.texture_state][self.character_face_direction]
        elif self.change_y != 0 and abs(self.change_y) >= abs(self.change_x):
            if self.change_y < 0:
                self.texture = self.move_down_texture_pair[self.character_face_direction]
            elif self.change_y > 0:
                self.texture = self.move_up_texture_pair[self.texture_state]
        else:
            self.texture = self.dead_textures[0]

    def update_texture(self):
        self.texture_state = 1 - self.texture_state

class Player_Attack(arcade.Sprite):
    def __init__(self,texture_list):
        super().__init__()

        self.current_texture = 0
        self.textures = texture_list

    def update(self):
        self.current_texture += 1
        if self.current_texture <len(self.textures):
            self.set_texture(self.current_texture)
        else:
            self.remove_from_sprite_lists()


class Projectile(arcade.Sprite):
    def __init__(self,character_face_direction):
        super().__init__()
        self.character_facing = character_face_direction
        self.fireball_texture_pair1 = [arcade.load_texture("Fireball1.png"), arcade.load_texture("Fireball1.png", mirrored=True)]
        self.fireball_texture_pair2 = [arcade.load_texture("Fireball2.png"), arcade.load_texture("Fireball2.png", mirrored=True)]
        self.fireball_textures = [self.fireball_texture_pair1, self.fireball_texture_pair2]
        self.scale = SPRITE_SCALING_FIREBALL
        self.texture = self.fireball_textures[0][self.character_facing]
        self.texture_state = 0

    def update_texture(self):
        self.texture_state = 1 - self.texture_state
        self.texture = self.fireball_textures[self.texture_state][self.character_facing]





class Terrain(arcade.Sprite):
    def __init__(self, type):
        super().__init__()
        self.textures = []
        stone_wall_texture = arcade.load_texture("Stone_Wall.jpg") #0
        self.textures.append(stone_wall_texture)
        rock_texture_1 = arcade.load_texture("rock1.png") #1
        self.textures.append(rock_texture_1)
        rock_texture_2 = arcade.load_texture("rock2.png") #2
        self.textures.append(rock_texture_2)


        if type == "W":
            self.scale = SPRITE_SCALING_STONEWALL
            self.set_texture(0)
        elif type == "R":
            self.scale = SPRITE_SCALING_ROCK
            self.set_texture(1)
        elif type == "r":
            self.scale = SPRITE_SCALING_ROCK
            self.set_texture(2)


class Decor(arcade.Sprite):
    def __init__(self, type):
        super().__init__()
        self.textures = []
        grave_texture = arcade.load_texture("Grave.png")
        self.textures.append(grave_texture)
        sign_left = arcade.load_texture("Sign.png")
        self.textures.append(sign_left)
        sign_right = arcade.load_texture("Sign.png", mirrored=True)
        self.textures.append(sign_right)
        self.win_condition = False

        if type == "G":
            self.scale = SPRITE_SCALING_GRAVE
            self.set_texture(0)
            self.win_condition = True

        elif type == "<":
            self.scale = SPRITE_SCALING_SIGN
            self.set_texture(1)

        if type == ">":
            self.scale = SPRITE_SCALING_SIGN
            self.set_texture(2)


class Enemy_Soldier(arcade.Sprite):
    def __init__(self):
        super().__init__()
        self.character_facing = LEFT_FACING
        self.soldier_texture_pair_1 = [arcade.load_texture("Enemy_Soldier1.png", mirrored=True), arcade.load_texture("Enemy_Soldier1.png")]
        self.soldier_texture_pair_2 = [arcade.load_texture("Enemy_Soldier2.png", mirrored=True),arcade.load_texture("Enemy_Soldier2.png")]
        self.soldier_textures = [self.soldier_texture_pair_1,self.soldier_texture_pair_2]
        self.scale = SPRITE_SCALING_SOLDIER
        self.texture = self.soldier_textures[0][self.character_facing]
        self.texture_state = 1

    def update_texture(self):
        self.texture_state = 1 - self.texture_state

    def update(self, end_x, end_y):
        if self.center_x < end_x and self.character_facing == LEFT_FACING:
            self.character_facing = RIGHT_FACING
        elif self.center_x > end_x and self.character_facing == RIGHT_FACING:
            self.character_facing = LEFT_FACING
        self.texture = self.soldier_textures[self.texture_state][self.character_facing]
        x_diff, y_diff = end_x - self.center_x, end_y - self.center_y
        angle = math.atan2(y_diff, x_diff)
        self.change_x = math.cos(angle)
        self.change_y = math.sin(angle)

class Enemy_Mage(arcade.Sprite):
    def __init__(self, type):
        super().__init__()
        self.character_facing = LEFT_FACING
        self.mage_texture_pair_1 = [arcade.load_texture("Enemy_Mage1.png", mirrored=True), arcade.load_texture("Enemy_Mage1.png")]
        self.mage_texture_pair_2 = [arcade.load_texture("Enemy_Mage2.png", mirrored=True), arcade.load_texture("Enemy_Mage2.png")]
        self.mage_textures = [self.mage_texture_pair_1, self.mage_texture_pair_2]

        if type == "M":
            self.scale = SPRITE_SCALING_MAGE
            self.texture = self.mage_textures[0][self.character_facing]
            self.charges = random.randint(0,2)

            self.texture_state = 1

    def update_texture(self):
        self.texture_state = 1 - self.texture_state

    def update(self, player_x):
        if self.center_x < player_x and self.character_facing == LEFT_FACING:
            self.character_facing = RIGHT_FACING
        elif self.center_x > player_x and self.character_facing == RIGHT_FACING:
            self.character_facing = LEFT_FACING
        self.texture = self.mage_textures[self.texture_state][self.character_facing]






class GameView(arcade.View):

    def __init__(self):
        super().__init__()

        self.player_list = None
        self.player_sprite = None

        self.enemy_list = None
        self.mage_list = None
        self.soldier_list = None
        self.wall_list = None
        self.projectile_list = None
        self.hearts_list = None
        self.attack_list = None
        self.decor_list = None

        self.enemy_physics_list = []

        self.score = 0
        self.health = 3

        arcade.set_background_color(arcade.color.BANANA_MANIA)
        self.room_coords = [0, 0]
        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False

        self.animation_ticks = 0
        self.invul = 0
        self.attack_cooldown = 0

        self.attack_texture_list = []
        file_name ="Attack_Effect.png"
        self.attack_texture_list = arcade.load_spritesheet(file_name,64,64,5,10)

    def setup(self):
        self.paused = False
        self.game_over = False

        self.player_list = arcade.SpriteList()
        self.wall_list = arcade.SpriteList()
        self.enemy_list = arcade.SpriteList()
        self.mage_list = arcade.SpriteList()
        self.soldier_list = arcade.SpriteList()
        self.hearts_list = arcade.SpriteList()
        self.projectile_list = arcade.SpriteList()
        self.attack_list = arcade.SpriteList()
        self.decor_list = arcade.SpriteList()



        self.score = 0
        self.player_sprite = Player()
        self.player_sprite.center_x = 400
        self.player_sprite.center_y = 400
        self.player_sprite.speed_limit = 3
        self.player_sprite.acceleration = 0.5
        self.player_list.append(self.player_sprite)

        for i in range(self.health):
            self.heart = arcade.Sprite("Heart_Full.png",SPRITE_SCALING_HEART)
            self.heart.center_y = SCREEN_HEIGHT - self.heart.height
            self.heart.center_x = (self.heart.width+1) * (i+1)
            self.hearts_list.append(self.heart)


        self.load_room(self.room_coords)


    def on_draw(self):
        arcade.start_render()
        self.decor_list.draw()
        self.wall_list.draw()
        self.enemy_list.draw()
        self.attack_list.draw()
        self.player_list.draw()
        self.hearts_list.draw()
        #output = f"Score:{self.score}"
        #arcade.draw_text(output, 10, 20, arcade.color.BLACK, 14)


    def update(self, delta_time):
        self.player_sprite.update(self.left_pressed, self.right_pressed, self.up_pressed, self.down_pressed, self.room_coords)
        self.player_sprite.update_facing()
        self.attack_list.update()
        for soldier in self.soldier_list:
            soldier.update(self.player_sprite.center_x,self.player_sprite.center_y)
        for mage in self.mage_list:
            mage.update(self.player_sprite.center_x)
        for decor in self.decor_list:
            if decor.win_condition == True and arcade.check_for_collision(decor, self.player_sprite) == True:
                victoryview = VictoryView(self.score)
                self.window.show_view(victoryview)


        for enemy in self.enemy_list:
            enemy.center_x += enemy.change_x
            enemy.center_y += enemy.change_y

        self.invul = self.invul - 1 if self.invul > 0 else 0
        self.attack_cooldown = self.attack_cooldown - 1 if self.attack_cooldown > 0 else 0

        for enemy in self.enemy_list:
            if arcade.check_for_collision(enemy, self.player_sprite) == True and self.invul == 0:
                self.take_damage()
            hit_list = arcade.check_for_collision_with_list(enemy, self.attack_list)
            if len(hit_list) > 0:
                enemy.remove_from_sprite_lists()
                self.score += 1

        for projectile in self.projectile_list:
            hit_list = arcade.check_for_collision_with_list(projectile, self.wall_list)
            if len(hit_list) > 0: projectile.remove_from_sprite_lists()


        self.animation_ticks += 1
        if self.animation_ticks == 61:
            self.animation_ticks = 1

            for mage in self.mage_list:
                mage.charges += 1
                if mage.charges >= 3:
                    mage.charges -= 3
                    self.mage_fireball(mage.center_x, mage.center_y, self.player_sprite.center_x, self.player_sprite.center_y)

        elif self.animation_ticks % 20 == 0:
            self.player_sprite.update_texture()
            if self.invul > 0:
                self.player_sprite.alpha = (355 - self.player_sprite.alpha)


        elif self.animation_ticks % 30 == 0:
            for mage in self.mage_list:
                mage.update_texture()
            for soldier in self.soldier_list:
                soldier.update_texture()

        if self.animation_ticks %10 == 0:
            for projectile in self.projectile_list:
                projectile.update_texture()


        for physics in self.enemy_physics_list:
            physics.update()

        self.physics_player_wall.update()
        self.room_update()



    def mage_fireball(self, start_x, start_y, end_x, end_y):
        x_diff, y_diff = end_x - start_x, end_y - start_y
        angle = math.atan2(y_diff, x_diff)
        magnitude_x = math.cos(angle)
        character_facing = 0 if magnitude_x < 0 else 1
        self.fireball_sprite = Projectile(character_facing)

        self.fireball_sprite.center_x, self.fireball_sprite.center_y = start_x, start_y
        self.fireball_sprite.change_x = math.cos(angle) * FIREBALL_SPEED
        self.fireball_sprite.change_y = math.sin(angle) * FIREBALL_SPEED
        self.projectile_list.append(self.fireball_sprite)
        self.enemy_list.append(self.fireball_sprite)


    def take_damage(self):
        self.health -= 1
        self.score -= 5
        self.invul = 120
        for hearts in self.hearts_list[self.health:]:
            hearts.color = arcade.color.BLACK

        if self.health == 0:
            game_over_view = GameOverView(self.score)
            self.window.show_view(game_over_view)

    def room_update(self):
        if self.player_sprite.center_y >= SCREEN_HEIGHT:
            self.player_sprite.center_y -= SCREEN_HEIGHT
            self.clear_room()
            self.room_coords[1] += 1
            self.load_room(self.room_coords)
        elif self.player_sprite.center_y <= 0:
            self.player_sprite.center_y += SCREEN_HEIGHT
            self.clear_room()
            self.room_coords[1] -= 1
            self.load_room(self.room_coords)
        elif self.player_sprite.center_x >= SCREEN_WIDTH:
            self.player_sprite.center_x -= SCREEN_WIDTH
            self.clear_room()
            self.room_coords[0] += 1
            self.load_room(self.room_coords)
        elif self.player_sprite.center_x <= 0:
            self.player_sprite.center_x += SCREEN_WIDTH
            self.clear_room()
            self.room_coords[0] -= 1
            self.load_room(self.room_coords)




    def on_key_press(self, key, modifiers):
        if key == arcade.key.A:
            self.left_pressed = True
        elif key == arcade.key.D:
            self.right_pressed = True
        elif key == arcade.key.W:
            self.up_pressed = True
        elif key == arcade.key.S:
            self.down_pressed = True
        elif key == arcade.key.T:
            self.clear_room()
        elif key == arcade.key.R:
            print(self.wall_list)

    def on_key_release(self, key, modifiers):
        if key == arcade.key.A:
            self.left_pressed = False
        elif key == arcade.key.D:
            self.right_pressed = False
        elif key == arcade.key.W:
            self.up_pressed = False
        elif key == arcade.key.S:
            self.down_pressed = False

    def on_mouse_press(self, x, y, button, modifiers):
        if button == arcade.MOUSE_BUTTON_LEFT and self.attack_cooldown == 0:
            attack = Player_Attack(self.attack_texture_list)
            direction = -1 if self.player_sprite.character_face_direction == 0 else 1
            attack.center_x = self.player_sprite.center_x + (direction*self.player_sprite.width*1.4)
            attack.center_y = self.player_sprite.center_y
            attack.angle = 180 if direction == 1 else 0
            attack.scale = 1.2
            attack.update()
            self.attack_list.append(attack)
            self.attack_cooldown = 60

    def clear_room(self):
        for i in range(6):
            for wall in self.wall_list:
                wall.remove_from_sprite_lists()
            for enemy in self.enemy_list:
                enemy.remove_from_sprite_lists()
            for decor in self.decor_list:
                decor.remove_from_sprite_lists()
        self.enemy_physics_list = []

    def load_room(self, room_coords):

        room_str = map.get(tuple(room_coords))
        lines = room_str.splitlines()
        lines.reverse()

        for y,line in enumerate(lines):
            data = line.split(' ')
            center_y = (y) * 50 +25
            for x, type in enumerate(data):
                center_x = (x) * 50 +25

                if type == "W" or type == "R" or type == "r":
                    self.terrain_sprite=Terrain(type)
                    self.terrain_sprite.center_x,self.terrain_sprite.center_y = center_x, center_y
                    self.wall_list.append(self.terrain_sprite)
                elif type == "M":
                    self.mage_sprite = Enemy_Mage(type)
                    self.mage_sprite.center_x,self.mage_sprite.center_y = center_x, center_y
                    self.enemy_list.append(self.mage_sprite)
                    self.mage_list.append(self.mage_sprite)
                elif type == "S":
                    self.soldier_sprite = Enemy_Soldier()
                    self.soldier_sprite.center_x, self.soldier_sprite.center_y = center_x, center_y
                    self.enemy_list.append(self.soldier_sprite)
                    self.soldier_list.append(self.soldier_sprite)
                    physics_soldier_wall = arcade.PhysicsEngineSimple(self.soldier_sprite, self.wall_list)
                    self.enemy_physics_list.append(physics_soldier_wall)
                elif type == "G" or type == ">" or type == "<":
                    self.decor_sprite = Decor(type)
                    self.decor_sprite.center_x, self.decor_sprite.center_y = center_x, center_y
                    self.decor_list.append(self.decor_sprite)



        self.physics_player_wall = arcade.PhysicsEngineSimple(self.player_sprite, self.wall_list)






class GameOverView(arcade.View):
    def __init__(self, score):
        super().__init__()
        self.total_score = score

    def on_show(self):
        arcade.set_background_color(arcade.color.BLACK)

    def on_draw(self):
        arcade.start_render()

        arcade.draw_text("You died! (again)", 240, 400, arcade.color.WHITE, 54)
        arcade.draw_text("Click to restart", 310, 300, arcade.color.WHITE, 24)

        arcade.draw_text(f"Your Score: {self.total_score}",
                         SCREEN_WIDTH / 2,
                         200,
                         arcade.color.GRAY,
                         font_size=15,
                         anchor_x="center")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        game_view = GameView()
        game_view.setup()
        self.window.show_view(game_view)

class VictoryView(arcade.View):
    def __init__(self,score):
        super().__init__()
        self.total_score = score
    def on_show(self):
        arcade.set_background_color(arcade.color.BEAU_BLUE)

    def on_draw(self):
        arcade.start_render()
        arcade.draw_text("Congratulations!", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, arcade.color.BLACK, font_size=50, anchor_x="center")
        arcade.draw_text("Your soul has been freed", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 50, arcade.color.BLACK, font_size=25, anchor_x="center")
        arcade.draw_text(f"Your Score: {self.total_score}", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 75, arcade.color.GRAY, font_size=15, anchor_x="center")
        arcade.draw_text("Click to play again", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 125,
                         arcade.color.GRAY, font_size=20, anchor_x="center")

    def on_mouse_press(self, _x, _y, _button, _modifiers):
        game_view = GameView()
        game_view.setup()
        self.window.show_view(game_view)






def main():
    window = arcade.Window(SCREEN_WIDTH, SCREEN_HEIGHT, "adventure")
    game_view = GameView()
    game_view.setup()
    window.show_view(game_view)

    arcade.run()


if __name__ == "__main__":
    main()


