WIDTH = 20
HEIGHT = 12


template='''
W W W W W W W W W W W W W W W W W W W W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W W W W W W W W W W W W W W W W W W W W
'''
room00='''
W W W W W W W W R X X R W W W W W W W W
W X X X X X X X X X X X R X X X X X W W
W X X X X X r X r X R X X r X X X X W W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X r X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X X
W X X X X X X X X X X X X X X X > X X X
W W W W X X X X X X X X X X X X X X X X
W X X W X X X X X X X X X X X X X W W W
W R X X X X X X X X X X X X X X W W W W
W W W W W W W W W W W W W W W W W W W W
'''
room10='''
W W W W W W W W W W W W W W W W X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X R X r W W W W W W W
W X X X X X X X X X X R R X X X X X X X
X X X > X X X X R X X r X X X X X X X X
X X X X X X X X X X R r X X X X X X X W
X X X X X X X X > X X R X > X G X X X W
W X X X X X X X X r X W X X X X X X X W
W X X X X X X X X X X W X X X X X X X W
W W W W W W W W W W W W W W W W W W W W
'''
room11='''
W W W W W W W W W W W W W W W W W W W W
W X X r X X X X X X X X X X X X X X X W
W X X X X X X X r X X X X X X X X X X W
W X X X X R X X X X X X X X X X X X X W
X X X X R X r X X X X X X X X X X X X X
X X X R X S R X X X X X X X X X X X X X
W X X X r R X X X X r X X X X X X X X X
W X X X X X X X X X X X X X X X X X X X
W X X X X X R X X X X X X X X X X X X W
W X X R X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W W W W W W W W W W W W W W W W X X X W
'''
room21='''
W W W W W W W W W W W W W W W W W W W W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X S X W
W X X X X X X X X X X X X X X X X X X W
X X X X X X X X X X X X X X X X X X X W
X X X X X X X X X Swwwwww X X X X X X X X X W
X X X X X X X X X X X X X X X X X X X W
X X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X S X W
W X X X X X X X X X X X X X X X X X X W
W W W W W W W W W W W W W W W W W W W W
'''
room01='''
W X X X W W W W W W W W W W W W W W W W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X S X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X X
W X X X X X X X X X X X X X X X X X X X
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X R X X X X r X X X X X X X X W
W X S X X X X r r R R R X X X X X X X W
W X X X R X R X X X X X r X X X X X X W
W W W W W W W W r X X R W W W W W W W W
'''
room02='''
W W W W W W W W W W W W W W W W W W W W
W S X X X X X X W X W X X X X X r X X X
W X W W W W W X W X X X W W W W W X W W
W X X X W X W X X X W X W X W X X X X W
W X W X W X W W W X W X X X W X r R X W
W X W W W X W X X X r X W X X X R X X W
W X W X X X X W W W W W W W W W W W X W
W X W X W W X R X W X W X X X X X X X W
W X W X W X X r X X X W X W W W W W W W
W X X X W X R W X W X X X W X X X W X W
W X X X W X X X X X X W X X X W X X X X
W X X X W W W W W W W W W W W W W W W W
'''
room12='''
W W W W W W W W W W W W W W W W W W W W
X X X X X X X X X W X X X X X X X X X W
W X X X X X X X X W X X X X X X X X X X
W X X X X X X X X W W X X X X X X X X X
W X X X X X X X X X W X X X X X X X X W
W X S X X X X X X X W W W W W W W W W W
W X X X X X X X X X X X X X X X X X X W
W W W W W W W W W W W X X S X X X S X W
W X X X X X X X X X X X X X X X X X X X
W X X X X X X X X X X X X X X S X M X X
X X X X X X X X X X X X X X X X X X X X
W W W W W W W W W W W W W W W W W W W W
'''
room22='''
W W W W W W W W W W X X W W W W W W W W
W X X X X X X X X R X X X X R X X X X W
X X X X X r X X X X X X X X X X X X X W
X X X X X X X X X X R X X X X X X X X W
W R X X X X X X X X X X X X r X X X X W
W X X X X X X X X X X X X X X X X R X X
W X X R X X X X r r X X X X X X X X X W
W r X X X X X X X X X X R X X X X X X W
X X X X R X X X X R X X X X X r X X X W
X X X X X X R X X X X X X R r X X r X W
X X X r X r X X X X X X X X X X X X r W
W W W W W W W W W W W W W W W W W W W W
'''
room23='''
W W W W W W W W W W W W W W W W W W W W
W X X X X X X X X X X X X X X X X X X W
W X M X X S X X S X X S X X S X X M X W
W X X S X X X X X X X X X X X X S X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X S X X X X X X X X X X S X X X W
W X X X X X X X X X X X X X X X X X X W
W X X X X X X X X X X X X X X X X X X W
W X M X X X X X X X X X X X X X X M X W
W X X X X X X X X X X X X X X X X X X W
W W W W W W W W W W X X W W W W W W W W
'''
room32='''
X X r X X X X X X X X X X X X X X X X X
X X X X X X X X X X X X X X X X R X X X
X X X X X X X X R X X X X X X X X X X X
X X W W W X X X X X X X X X X X X X r X
W W W X W W W W W W W W W W W W W W W W
X X X X X X X X X X X X X X X X X M X W
W W W W W W R W W W W X W W W W W W X W
W X X X X W X W X X W X W X X X X r X W
W X X X X W X r X X W X W X r X X R X W
W X X X W W X W W W W W W X R R R R X W
W X X M X X X X X X X X X X X X X X X W
W X X W W W W W W W W W W W W W W W W W
'''
room31='''
W X X W W W W W W W W W W W W W W W W W
W X X X X X X X X X X X X X X X X X X W
W X X X W X X X X X X X X X X X X M X W
W X X X W W X X X X X X r X X M X X X W
W X X X X W X X X X X X X X X X X M X W
W X X X X X X X X X X X X X X M X X X W
W X X X X X R R X X X R X X X X X M X W
W X X X X X r X X X X X X X X M X X X W
W X r X X X X X X X X X X X X X X M X W
W X X X X X X W W X X X X X X M X X X W
W X X R X X X W W X X X X R X X X X X W
W W W W W W W W W W W W W W W W X X X W
'''
room30='''
W W W W W W W W W W W W W W W W X X X W
W X W X X W X X X X X X X W X R X X X W
W X W W X W X W X W W X X X X W W X R W
W X X X X X X W W X W X W W X W X X X W
W r W W W W W W X X X X X W X W X W X W
X X W r X X X W W W W W X W X W X W X W
X X X X W W X W X W X X X X X X X W X W
W X W R W X X X X X W W X W R W W W X W
W X X X W X X W W X X W X W X W X X X W
W R W X W R X W X X W W X W X W W W X W
W X X X X X X X W X X X X X X X X X X W
W W W W W W W W W W W W W W W W W W W W
'''
room20='''
W W W W W W W W W W W W W W W W W W W W
W X X X X X R X X X X X X X X X X X S W
W X M X X X X X X X X X X X R X X M S W
W X X X X X X X X X X X X X X X X X S W
W X X X r X X X X X X X X X X X X W W W
X X S X X X X X X X X X X X X X X X X X
X X S X X X X X X X X X X X X X X X X X
W X X X X X R X X X X X X X X X X W W W
W X X X X X X X X X X X X X X X X X S W
W X M X X X X X X r X X X X X X X M S W
W X X X X X X X X X X X X X X X X X S W
W W W W W W W W W W W W W W W W W W W W
'''
map={(0,0):room00,(1,0):room10,(1,1):room11,(2,1):room21,(0,1):room01,(0,2):room02,(1,2):room12,(2,2):room22,(2,3):room23,(3,2):room32,(3,1):room31,
     (3,0):room30,(2,0):room20}