import arcade
import random
import math
#from Stages import map

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 600
VIEWPORT_MARGIN = 65
WORLD_BORDER = 2025
LEFT_FACING, RIGHT_FACING = 0, 1
SPRITE_SCALING_PLAYER, SPRITE_SCALING_GUI, SPRITE_SCALING_GUI_ICON = 0.75, 1, 0.6
SPRITE_SCALING_ROCK, SPRITE_SCALING_WALL, SPRITE_SCALING_TREE, SPRITE_SCALING_FURNITURE = 1, 1, 1, 1
DAMAGE_PUNCH, DAMAGE_PICKAXE, DAMAGE_AXE, DAMAGE_KNIFE = 1, 3, 3, 4
ENEMY_MOVE_SPEED, PLAYER_MOVE_SPEED = 1, 7

class GUI(arcade.Sprite):
    def __init__(self, icon=True, slot_no=0, texture=None, type="NIL", menu=False, lvl=0):
        super().__init__()
        self.slot_position = slot_no
        self.icon = icon
        self.type = type
        self.menu = menu
        self.can_be_placed = False
        if icon == True and menu == False:
            self.hammer_icon = arcade.load_texture("Hammer.png")
            self.empty_icon = arcade.load_texture("Blank_Icon.png")
            self.back_icon = arcade.load_texture("Back_Icon.png")
            self.table_icon = arcade.load_texture("Table.png")
            self.tools_icon = arcade.load_texture("Tools_Icon.png")
            self.stonewall_icon = arcade.load_texture("Stone_wall_grey.png")

            self.texture_dict = {"BUILD":self.hammer_icon, "CRAFT":self.tools_icon, "NIL":self.empty_icon, "BACK":self.back_icon, "TABLE":self.table_icon, "STONE_WALL":self.stonewall_icon}
            self.texture = self.texture_dict[self.type]
            self.build_list = ["TABLE", "STONE_WALL"]
            self.scale = SPRITE_SCALING_GUI_ICON
            self.y = SCREEN_HEIGHT - 32 - 55 * (self.slot_position - 1)

            if (self.type in self.build_list) == True:
                self.can_be_placed = True



        elif icon == True and menu == True:
            self.pickaxe_icon_list = [arcade.load_texture("Pickaxe.png"),arcade.load_texture("Blank_Icon.png")]
            self.axe_icon_list = [arcade.load_texture("Axe.png"),arcade.load_texture("Blank_Icon.png")]
            self.weapon_icon_list = [arcade.load_texture("Weapon.png"),arcade.load_texture("Blank_Icon.png")]
            self.texture_dict = {"PICKAXE": self.pickaxe_icon_list, "AXE": self.axe_icon_list, "WEAPON": self.weapon_icon_list}
            self.texture = self.texture_dict[self.type][lvl]





        else:
            self.texture = texture
            self.scale = SPRITE_SCALING_GUI

    def load_toolbar(self, menu_type):

        if menu_type == "BACK":
            main_menu = ["BUILD", "CRAFT", "NIL", "BACK"]
            self.type = main_menu[self.slot_position-1]
        elif menu_type == "BUILD":
            furniture_menu = ["TABLE", "STONE_WALL", "NIL", "BACK"]
            self.type = furniture_menu[self.slot_position-1]
        elif menu_type == "CRAFT":
            tools_menu = ["NIL", "NIL", "NIL", "BACK"]
            self.type = tools_menu[self.slot_position-1]

        self.texture = self.texture_dict[self.type]
        if (self.type in self.build_list) == True:
            self.can_be_placed = True
        else:
            self.can_be_placed = False



class Item(arcade.Sprite):
    def __init__(self, type, qty, x, y):
        super().__init__()
        self.center_x, self.center_y = x, y
        self.stacks = qty
        self.stone_texture = arcade.load_texture("Stone.png")
        self.stick_texture = arcade.load_texture("Stick.png")
        self.cloth_texture = arcade.load_texture("Cloth.png")
        self.current_texture = 0
        self.texture_cycle = [1,0,1,0,1,0,1,0,0,1,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,-1,0,-1,0,-1,0,-1,0,0,-1,0,0,-1,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0]
        self.type = type
        if type == "STONE":
            self.texture = self.stone_texture
        elif type == "STICK":
            self.texture = self.stick_texture
        elif type == "CLOTH":
            self.texture = self.cloth_texture



    def update(self):
        if self.current_texture >= len(self.texture_cycle):

            self.current_texture = 0
        self.center_y += 0.7 * self.texture_cycle[self.current_texture]
        self.current_texture += 1

class Hitbox(arcade.Sprite):
    def __init__(self, x, y, type):
        super().__init__()
        self.type = type
        self.stick_req = self.stone_req = self.cloth_req = 0
        if type == "PLAYER":
            self.texture = arcade.load_texture("Punch_Hitbox_Dev.png")
            self.scale = 1
            self.alpha = 0

            self.center_x, self.center_y = x + 20, y
        elif type == "MOUSE":
            self.texture = arcade.load_texture("Mouse_Hitbox.png")
            self.scale = 1
            self.alpha = 0
        elif type == "TABLE":
            self.texture = arcade.load_texture("Table.png")
            self.alpha = 170
            self.color = arcade.color.GO_GREEN
            self.scale = SPRITE_SCALING_FURNITURE
            self.can_place = False
            self.stone_req = 1
            self.stick_req = 5
            self.cloth_req = 0
        elif type == "STONE_WALL":
            self.texture = arcade.load_texture("Stone_wall.png")
            self.alpha = 170
            self.color = arcade.color.GO_GREEN
            self.scale = SPRITE_SCALING_FURNITURE
            self.can_place = False
            self.stone_req = 5
            self.stick_req = 0
            self.cloth_req = 0


    def update(self, x, y, character_facing=0):
        self.center_y = y

        direction = pow(-1,character_facing)
        self.center_x = x - (direction * 20)

    def update_preview(self, x, y, can_place):
        self.center_x, self.center_y = x, y
        self.can_place = can_place
        if self.can_place == True:
            self.color = arcade.color.GO_GREEN
        elif self.can_place == False:
            self.color = arcade.color.RED_DEVIL





class Player(arcade.Sprite):
    def __init__(self):
        super().__init__()
        self.character_facing = LEFT_FACING
        self.doing_action = False
        self.tool_type = "NIL"
        self.player_texture_list = []
        self.player_idle_textures = [arcade.load_spritesheet("Player_Idle_Mirrored.png", 50, 136, 7, 14), arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14)]
        self.player_run_textures = [arcade.load_spritesheet("Player_Run_Mirrored.png", 60, 136, 5, 5), arcade.load_spritesheet("Player_Run.png", 60, 136, 5, 5)]
        self.player_punch_textures = [arcade.load_spritesheet("Player_Punch_Mirrored.png", 75, 136, 5, 5), arcade.load_spritesheet("Player_Punch.png", 75, 136, 5, 5)]
        self.player_mine_textures = [arcade.load_spritesheet("Player_Mine_Mirrored.png", 100, 136, 4, 8), arcade.load_spritesheet("Player_Mine.png", 100, 136, 4, 8)]
        self.player_stab_textures = [arcade.load_spritesheet("Player_Stab_Mirrored.png", 100, 136, 3, 6), arcade.load_spritesheet("Player_Stab.png", 100, 136, 3, 6)]
        self.player_chop_textures = [arcade.load_spritesheet("Player_Chop_Mirrored.png", 100, 136, 4, 8), arcade.load_spritesheet("Player_Chop.png", 100, 136, 4, 8)]
        self.player_texture_list = self.player_idle_textures
        self.current_texture = 0
        self.textures = self.player_texture_list[self.character_facing]
        self.scale = SPRITE_SCALING_PLAYER

        self.move_type = "IDLE"
        self.action_hitbox_life = 0
        self.hit_damage = 0
        self.hp = 10
        self.max_hp = 10

        self.weapon_lvl = 0
        self.pickaxe_lvl = 0
        self.axe_lvl = 0
        self.pickaxe_req = ([5,4,0], [0,0,0]) #stone stick cloth
        self.axe_req = ([5,4,0], [0,0,0])
        self.weapon_req = ([5,4,0], [0,0,0])

    def update_texture(self):
        self.current_texture += 1
        test = self.player_texture_list[self.character_facing]
        if self.current_texture >= len(test):
            self.current_texture = 0
            if self.doing_action == True:
                self.idle()
                self.doing_action = False
        elif self.move_type == "PUNCH" and self.current_texture == 3:
            self.action_hitbox_life = 1

        elif (self.move_type == "MINE" or self.move_type == "STAB" or self.move_type == "CHOP") and self.current_texture == 4:
            self.action_hitbox_life = 1

        #self.textures = self.player_texture_list[self.character_facing]
        self.set_texture(self.current_texture)


    def update(self, left, right, up, down):
        if self.doing_action == True:
            self.change_y = 0
            self.change_x = 0
        else:
            self.center_y += self.change_y
            self.center_x += self.change_x

            max_speed = lambda speed: max(min(self.speed_limit, speed), -self.speed_limit)
            if left == True:
                self.change_x = max_speed(self.change_x - self.acceleration)
            if right == True:
                self.change_x = max_speed(self.change_x + self.acceleration)
            if right == True and left == True:
                self.change_x = 0
            if down == True:
                self.change_y = max_speed(self.change_y - self.acceleration)
            if up == True:
                self.change_y = max_speed(self.change_y + self.acceleration)
            if up == True and down == True:
                self.change_y = 0

            if up == False and down == False and self.change_y != 0:
                self.change_y *= 0.6
                if abs(self.change_y) < 0.3: self.change_y = 0
            if left == False and right == False and self.change_x != 0:
                self.change_x *= 0.6
                if abs(self.change_x) < 0.3: self.change_x = 0

            if self.change_x > 0 and self.character_facing == 0:
                self.character_facing = 1
                self.textures = self.player_texture_list[self.character_facing]
            elif self.change_x < 0 and self.character_facing == 1:
                self.character_facing = 0
                self.textures = self.player_texture_list[self.character_facing]




        if (self.change_x != 0 or self.change_y != 0) and self.move_type == "IDLE":
            self.run()

        elif self.change_x == 0 and self.change_y == 0 and self.move_type == "RUN":
            self.idle()


    def change_texture(self, texture_list):
        self.player_texture_list = texture_list
        self.current_texture = 0
        self.textures = self.player_texture_list[self.character_facing]

    def idle(self):
        self.change_texture(self.player_idle_textures)
        self.move_type = "IDLE"

    def run(self):
        self.change_texture(self.player_run_textures)
        self.move_type = "RUN"

    def punch(self):
        self.change_texture(self.player_punch_textures)
        self.move_type = "PUNCH"
        self.hit_damage = DAMAGE_PUNCH
        self.tool_type = "NIL"
        self.doing_action = True

    def stab(self):
        if self.weapon_lvl == 1:
            self.change_texture(self.player_stab_textures)
            self.move_type = "STAB"
            self.hit_damage = DAMAGE_KNIFE
            self.tool_type = "WEAPON"
            self.doing_action = True
        else: self.punch()

    def mine(self):
        if self.pickaxe_lvl == 1:
            self.change_texture(self.player_mine_textures)
            self.move_type = "MINE"
            self.hit_damage = DAMAGE_PICKAXE
            self.tool_type = "PICKAXE"
            self.doing_action = True
        else: self.punch()

    def chop(self):
        if self.axe_lvl == 1:
            self.change_texture(self.player_chop_textures)
            self.move_type = "CHOP"
            self.hit_damage = DAMAGE_AXE
            self.tool_type = "AXE"
            self.doing_action = True
        else: self.punch()




class Enemy(arcade.Sprite):
    def __init__(self, type, character_facing, x=0, y=0):
        super().__init__()
        self.type = type
        self.counter = 0
        self.current_texture = 0
        self.character_facing = character_facing
        self.center_x, self.center_y = x, y
        self.tool_type = "WEAPON"
        self.skeleton_idle_textures = [arcade.load_spritesheet("Skeleton_Idle_Mirrored.png", 50, 128, 4, 4), arcade.load_spritesheet("Skeleton_Idle.png", 50, 128, 4, 4)]
        self.skeleton_move_textures = [arcade.load_spritesheet("Skeleton_Run_Mirrored.png",60, 128, 5, 5), arcade.load_spritesheet("Skeleton_Run.png",60, 128, 5, 5)]
        self.ghost_textures = [arcade.load_spritesheet("Enemy_Ghost_Mirrored.png", 90, 110, 3, 9), arcade.load_spritesheet("Enemy_Ghost.png", 90, 110, 3, 9)]
        if self.type == "GHOST":
            self.enemy_textures = self.ghost_textures
            self.textures = self.enemy_textures[self.character_facing]
            self.hp = 4
            self.damage = 2
            self.alpha = 200
        elif self.type == "SKELETON":
            self.enemy_textures = self.skeleton_idle_textures
            self.textures = self.enemy_textures[self.character_facing]
            self.hp = 5
            self.damage = 3





    def update_texture(self):
        self.current_texture += 1
        if self.current_texture >= len(self.enemy_textures[self.character_facing]) - 1:
            self.current_texture = 0
        self.set_texture(self.current_texture)

    def update_ghost(self, player_x, player_y):
        if self.center_x < player_x and self.character_facing == LEFT_FACING:
            self.character_facing = RIGHT_FACING
        elif self.center_x >= player_x and self.character_facing == RIGHT_FACING:
            self.character_facing = LEFT_FACING
        self.textures = self.enemy_textures[self.character_facing]

        x_diff, y_diff = player_x - self.center_x, player_y - self.center_y
        angle = math.atan2(y_diff, x_diff)
        self.change_x += math.cos(angle) * ENEMY_MOVE_SPEED
        self.change_y += math.sin(angle) * ENEMY_MOVE_SPEED
        if abs(self.change_x) >= 1:self.change_x *= 0.4
        if abs(self.change_y) >= 1: self.change_y *= 0.4

    def update_skeleton(self, player_x, player_y):
        if self.center_x < player_x and self.character_facing == LEFT_FACING:
            self.character_facing = RIGHT_FACING
        elif self.center_x >= player_x and self.character_facing == RIGHT_FACING:
            self.character_facing = LEFT_FACING
        self.textures = self.enemy_textures[self.character_facing]
        x_diff, y_diff = player_x - self.center_x, player_y - self.center_y
        distance = pow(pow(x_diff, 2) + pow(y_diff, 2), 0.5)
        if distance >= 400:
            self.enemy_textures = self.skeleton_move_textures
            if abs(x_diff) >= abs(y_diff):
                x = (x_diff / abs(x_diff))
                self.change_x = ENEMY_MOVE_SPEED * x * 3
                self.change_y = 0
            elif abs(x_diff) < abs(y_diff):
                y = (y_diff / abs(y_diff))
                self.change_y = ENEMY_MOVE_SPEED * y * 3
                self.change_x = 0
        elif distance < 400:
            self.change_x, self.change_y = 0, 0
            self.counter += 1
            self.enemy_textures = self.skeleton_idle_textures


    def update_movement(self):
        self.center_x += self.change_x
        self.center_y += self.change_y

class Projectile(arcade.Sprite):
    def __init__(self, start_x, start_y, end_x, end_y, rotation=0, texture=arcade.load_texture("Stone.png"), speed=5):
        super().__init__()
        x_diff, y_diff = end_x - start_x, end_y - start_y
        angle = math.atan2(y_diff, x_diff)
        self.center_x, self.center_y = start_x, start_y
        self.change_x = math.cos(angle) * speed
        self.change_y = math.sin(angle) * speed
        self.change_angle = rotation
        self.texture = texture
        self.scale = 1
        self.hp = 1
        self.damage = 1
        self.type = "PROJECTILE"
        self.tool_type = "WEAPON"

    def update_movement(self):
        self.center_x += self.change_x
        self.center_y += self.change_y
        self.angle += self.change_angle

    def update_texture(self):
        pass


class Terrain(arcade.Sprite):
    def __init__(self,type,x,y):
        super().__init__()
        self.stone_wall_texture = arcade.load_texture("Stone_wall_grey.png")
        self.rock_texture = arcade.load_texture("Rock.png")
        self.tree_texture = arcade.load_texture("Tree.png")
        self.table_texture = arcade.load_texture("Table.png")
        self.grave_textures = [arcade.load_texture("Grave1.png"), arcade.load_texture("Grave2.png")]
        self.type = type
        self.tool_type = None
        self.center_x = x
        self.center_y = y



        if self.type == "ROCK":
            self.texture = self.rock_texture
            self.scale = SPRITE_SCALING_ROCK
            self.hp = 3
            self.tool_type = "PICKAXE"
        if self.type == "TREE":
            self.texture = self.tree_texture
            self.scale = SPRITE_SCALING_TREE
            self.hp = 3
            self.tool_type = "AXE"
        elif self.type == "STONE_WALL":
            self.texture = self.stone_wall_texture
            self.scale = SPRITE_SCALING_WALL
            self.hp = 20
            self.tool_type = "PICKAXE"
        elif self.type == "TABLE":
            self.texture = self.table_texture
            self.scale = SPRITE_SCALING_FURNITURE
            self.hp = 10
            self.tool_type = "AXE"
        elif type == "GRAVE":
            self.texture = self.grave_textures[random.randint(0, 1)]
            self.scale = SPRITE_SCALING_WALL
            self.hp = 999
            self.tool_type = "PICKAXE"









class GameView(arcade.View):

    def __init__(self):
        super().__init__()

        self.player_list = None
        self.player_sprite = None
        self.projectile_list = None
        self.hitbox_list = None
        self.GUI_list = None
        self.enemy_list = None
        self.terrain_list = None
        self.breakable_terrain_list = None
        self.impassable_terrain_list = None
        self.resource_list = None
        self.item_list = None
        self.spawn_list = None

        self.stones = 0
        self.sticks = 0
        self.cloth = 0



        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False
        self.mouse_selected = None
        self.mouse_x, self.mouse_y = 0, 0

        self.preview_exists = False
        self.game_paused = False


        arcade.set_background_color(arcade.color.BANANA_MANIA)
        self.view_bottom = 0
        self.view_left = 0
        self.animation_ticks = 0
        self.invul = 0
        self.animation_ticks = 0
        self.time = 0




    def setup(self):
        self.player_list = arcade.SpriteList()
        self.projectile_list = arcade.SpriteList()
        self.enemy_list = arcade.SpriteList()
        self.terrain_list = arcade.SpriteList()
        self.breakable_terrain_list = arcade.SpriteList()
        self.impassable_terrain_list = arcade.SpriteList()
        self.resource_list = arcade.SpriteList()
        self.hitbox_list = arcade.SpriteList()
        self.item_list = arcade.SpriteList()
        self.GUI_list = arcade.SpriteList()
        self.spawn_list = arcade.SpriteList()


        self.player_sprite = Player()
        self.player_sprite.center_x, self.player_sprite.center_y = SCREEN_WIDTH/2, SCREEN_HEIGHT/2
        self.player_sprite.update_texture()
        self.player_sprite.acceleration = 1
        self.player_sprite.speed_limit = 4
        self.player_list.append(self.player_sprite)

        self.player_melee_hitbox = Hitbox(self.player_sprite.center_x,self.player_sprite.center_y, "PLAYER")
        self.player_melee_hitbox.update(self.player_sprite.center_x,self.player_sprite.center_y,self.player_sprite.character_facing)
        self.hitbox_list.append(self.player_melee_hitbox)

        self.mouse_hitbox = Hitbox(0, 0, "MOUSE")
        self.hitbox_list.append(self.mouse_hitbox)

        self.time_shader = GUI(icon=False, texture=arcade.load_texture("Time_Shader.png"))
        self.time_shader.center_x, self.time_shader.center_y = SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2
        self.time_shader.alpha = 200
        self.hitbox_list.append(self.time_shader)

        self.GUI_inventory = GUI(icon=False, texture=arcade.load_texture("GUI_inventory.png"))
        self.GUI_inventory.center_x = self.view_left + self.GUI_inventory.width/2
        self.GUI_inventory.center_y = self.view_bottom + SCREEN_HEIGHT - self.GUI_inventory.height/2
        self.GUI_list.append(self.GUI_inventory)

        self.GUI_toolbar = GUI(icon=False, texture=arcade.load_texture("GUI_toolbar.png"))
        self.GUI_toolbar.center_x = self.view_left + SCREEN_WIDTH - self.GUI_toolbar.width/2
        self.GUI_toolbar.center_y = self.view_bottom + SCREEN_HEIGHT - self.GUI_toolbar.height / 2
        self.GUI_list.append(self.GUI_toolbar)

        self.GUI_healthbar = GUI(icon=False, texture=arcade.load_texture("GUI_healthbar.png"))
        self.GUI_healthbar_y = SCREEN_HEIGHT - self.GUI_inventory.height - self.GUI_healthbar.height/2
        self.GUI_healthbar.center_x = self.view_left + self.GUI_healthbar.width/2
        self.GUI_healthbar.center_y = self.view_bottom + SCREEN_HEIGHT - self.GUI_inventory.height - self.GUI_healthbar.height/2 - 1
        self.GUI_list.append(self.GUI_healthbar)

        main_menu = ["BUILD", "CRAFT", "NIL", "BACK"]
        for i in range(1, 5):

            self.GUI_toolbar_icon = GUI(slot_no=i, type=main_menu[i-1])
            self.GUI_toolbar_icon.center_x = self.view_left + SCREEN_WIDTH - self.GUI_toolbar.width/2
            self.GUI_toolbar_icon.center_y = self.view_bottom + self.GUI_toolbar_icon.y
            self.GUI_list.append(self.GUI_toolbar_icon)





        for i in range(-WORLD_BORDER,WORLD_BORDER+1,50):
            terrain = Terrain("STONE_WALL", i, WORLD_BORDER)
            self.impassable_terrain_list.append(terrain)
            self.terrain_list.append(terrain)
            terrain = Terrain("STONE_WALL", i, -WORLD_BORDER)
            self.impassable_terrain_list.append(terrain)
            self.terrain_list.append(terrain)
            terrain = Terrain("STONE_WALL", WORLD_BORDER, i)
            self.impassable_terrain_list.append(terrain)
            self.terrain_list.append(terrain)
            terrain = Terrain("STONE_WALL", -WORLD_BORDER, i)
            self.impassable_terrain_list.append(terrain)
            self.terrain_list.append(terrain)


        terrain_spawn = WORLD_BORDER - 500
        for i in range(20):
            x = random.randint(-terrain_spawn, terrain_spawn+1)
            y = random.randint(-terrain_spawn, terrain_spawn+1)
            rock = Terrain("ROCK", x, y)
            self.breakable_terrain_list.append(rock)
            self.terrain_list.append(rock)
            self.resource_list.append(rock)
            x = random.randint(-terrain_spawn, terrain_spawn+1)
            y = random.randint(-terrain_spawn, terrain_spawn+1)
            tree = Terrain("TREE", x, y)
            self.breakable_terrain_list.append(tree)
            self.terrain_list.append(tree)
            self.resource_list.append(tree)
        self.physics_player_wall = arcade.PhysicsEngineSimple(self.player_sprite, self.impassable_terrain_list)


        for i in range(15):
            grave = Terrain("GRAVE", 3000, 3000)
            successfully_placed = False
            while not successfully_placed:
                x = [random.randint(WORLD_BORDER-200, WORLD_BORDER-75), random.randint(-WORLD_BORDER+75, WORLD_BORDER-75)]
                y = [random.randint(-WORLD_BORDER+75, WORLD_BORDER-75), random.randint(WORLD_BORDER-200, WORLD_BORDER-75)]
                val = random.randint(0, 1)
                neg = pow(-1, random.randint(1, 2))
                grave.center_x, grave.center_y = neg * x[val], neg * y[val]
                terrain_hit_list = arcade.check_for_collision_with_list(grave, self.terrain_list)
                if len(terrain_hit_list) == 0:
                    successfully_placed = True
            self.terrain_list.append(grave)
            self.spawn_list.append(grave)









        self.enemy_physics_list = []






    def on_draw(self):
        arcade.start_render()

        self.terrain_list.draw()
        self.item_list.draw()
        self.player_list.draw()
        self.enemy_list.draw()

        self.hitbox_list.draw()
        self.GUI_list.draw()


        output = f"{min(self.stones,99)}"
        y = self.view_bottom + SCREEN_HEIGHT - self.GUI_inventory.height * 0.9
        arcade.draw_text(output, self.view_left + 43, y, color=arcade.color.ARYLIDE_YELLOW, font_size=25, align="left")

        output = f"{min(self.sticks,99)}"
        arcade.draw_text(output,self.view_left + 123, y, color=arcade.color.ARYLIDE_YELLOW, font_size=25, align="left")

        output = f"{min(self.cloth,99)}"
        arcade.draw_text(output, self.view_left + 203, y, color=arcade.color.ARYLIDE_YELLOW, font_size=25, align="left")

        healthbar_length = round(self.player_sprite.hp/self.player_sprite.max_hp * 200)
        l, r = self.view_left + 20, self.view_left + 19 + healthbar_length
        t, b = self.view_bottom + self.GUI_healthbar_y + 5, self.view_bottom + self.GUI_healthbar_y - 5
        try: arcade.draw_lrtb_rectangle_filled(l, r, t, b, arcade.color.FOREST_GREEN)
        except: pass

    def create_projectile(self, x1, y1, x2, y2, rotation, texture):
        projectile = Projectile(x1, y1, x2, y2, rotation, texture)
        self.enemy_list.append(projectile)
        self.projectile_list.append(projectile)




    def update(self, delta_time: float):
        self.mouse_hitbox.center_x, self.mouse_hitbox.center_y = self.view_left + self.mouse_x, self.view_bottom + self.mouse_y

        if self.game_paused == False:
            self.animation_ticks += 1
            self.update_view()
            self.item_list.update()
            self.pickup_items()

            self.player_sprite.update(self.left_pressed, self.right_pressed, self.up_pressed, self.down_pressed)
            self.player_melee_hitbox.update(self.player_sprite.center_x, self.player_sprite.center_y,self.player_sprite.character_facing)

            for enemy in self.enemy_list:
                if enemy.type == "GHOST":
                    enemy.update_ghost(self.player_sprite.center_x, self.player_sprite.center_y)

                elif enemy.type == "SKELETON":
                    enemy.update_skeleton(self.player_sprite.center_x, self.player_sprite.center_y)
                    if len(arcade.check_for_collision_with_list(enemy, self.impassable_terrain_list)) > 0:
                        enemy.change_x *= -2
                        enemy.change_y *= -2
                    elif enemy.counter > 180:
                        enemy.counter = 0
                        self.create_projectile(enemy.center_x, enemy.center_y + 50, self.player_sprite.center_x, self.player_sprite.center_y, 30, arcade.load_texture("Stone.png"))
                elif enemy.type == "PROJECTILE":
                    pass
                enemy.update_movement()

            if self.preview_exists == True:
                terrain_blocking = arcade.check_for_collision_with_list(self.furniture_preview, self.terrain_list)
                GUI_blocking = arcade.check_for_collision_with_list(self.mouse_hitbox, self.GUI_list)
                blocking_list = terrain_blocking + GUI_blocking
                if arcade.check_for_collision(self.player_sprite, self.furniture_preview) == True or len(blocking_list)>0 or self.stones < self.furniture_preview.stone_req or self.sticks < self.furniture_preview.stick_req:
                    can_place = False
                else:can_place = True
                self.furniture_preview.update_preview(self.mouse_hitbox.center_x, self.mouse_hitbox.center_y, can_place)


            if self.animation_ticks == 61:
                self.update_time()
                self.animation_ticks = 1
                if self.invul <= - 300 and self.player_sprite.hp < self.player_sprite.max_hp:
                    self.player_sprite.hp = min((self.player_sprite.hp + 1), self.player_sprite.max_hp)

            if self.animation_ticks % 5 == 0:
                self.player_sprite.update_texture()
                if self.time <= 5:
                    self.time_shader.alpha = max(self.time_shader.alpha - 10, 0)
                elif self.time >= 145 and self.time <= 150:
                    self.time_shader.alpha = min(self.time_shader.alpha + 10, 180)
            if self.animation_ticks % 10 == 0:
                for enemy in self.enemy_list: enemy.update_texture()


            if self.player_sprite.action_hitbox_life > 0:
                self.player_sprite.action_hitbox_life -= 1
                self.damage_entity()


            self.invul -= 1
            if self.invul <= 0:
                hitbox_overlap = arcade.check_for_collision_with_list(self.player_sprite, self.enemy_list)
                if len(hitbox_overlap) > 0:
                    self.player_damaged(hitbox_overlap)


            self.physics_player_wall.update()
            for enemy in self.enemy_physics_list:
                enemy.update()


        elif self.game_paused == True and self.preview_exists == True:
            self.delete_preview()

    def update_time(self):
        self.time += 1
        time = self.time

        for projectile in self.projectile_list:
            x = projectile.center_x
            y = projectile.center_y
            if (x < self.view_left or x > self.view_left + SCREEN_WIDTH) or (y < self.view_bottom or y > self.view_bottom + SCREEN_HEIGHT):
                projectile.remove_from_sprite_lists()
            else: continue
        
        if time == 300:
            self.time = 0
        elif time > 150 and len(self.enemy_list) <= 10:
            chance = random.random()
            if chance < 0.5:
                spawnpoint = self.spawn_list[random.randint(0, len(self.spawn_list)-1)]
                enemy_list = ["GHOST", "SKELETON"]
                ghost = Enemy(enemy_list[random.randint(0,len(enemy_list)-1)], LEFT_FACING, spawnpoint.center_x, spawnpoint.center_y)
                self.enemy_list.append(ghost)
                ghost.update_texture()
        elif len(self.resource_list) < 50:
            tree_count, rock_count = 0, 0
            terrain_spawn = WORLD_BORDER - 500
            x = random.randint(-terrain_spawn, terrain_spawn + 1)
            y = random.randint(-terrain_spawn, terrain_spawn + 1)
            for object in self.resource_list:
                if object.type == "TREE":
                    tree_count += 1
                elif object.type == "ROCK":
                    rock_count += 1

            if tree_count >= rock_count:
                resource = Terrain("TREE", x, y)
            else:
                resource = Terrain("ROCK", x, y)

            placed_successfully = False
            while not placed_successfully:
                x = random.randint(-terrain_spawn, terrain_spawn + 1)
                y = random.randint(-terrain_spawn, terrain_spawn + 1)
                resource.center_x, resource.center_y = x, y
                terrain_hit_list = arcade.check_for_collision_with_list(resource, self.terrain_list)
                if len(terrain_hit_list) == 0:
                    placed_successfully = True

            self.breakable_terrain_list.append(resource)
            self.terrain_list.append(resource)
            self.resource_list.append(resource)














    def pickup_items(self):
        item_list = arcade.check_for_collision_with_list(self.player_sprite, self.item_list)
        for item in item_list:
            if item.type == "STONE":
                self.stones += item.stacks
            elif item.type == "STICK":
                self.sticks += item.stacks
            elif item.type == "CLOTH":
                self.cloth += item.stacks
            item.remove_from_sprite_lists()

    def damage_entity(self):
        hit_list = []
        for breakable_terrain in arcade.check_for_collision_with_list(self.player_melee_hitbox, self.breakable_terrain_list):
            hit_list.append(breakable_terrain)
        for enemy in arcade.check_for_collision_with_list(self.player_melee_hitbox, self.enemy_list):
            hit_list.append(enemy)

        for object in hit_list:
            if object.tool_type == self.player_sprite.tool_type:
                object.hp -= self.player_sprite.hit_damage

            elif object.tool_type != self.player_sprite.tool_type:
                object.hp -= self.player_sprite.hit_damage * 0.5

            if isinstance(object, Enemy) == True:
                object.change_x = self.player_sprite.hit_damage * self.player_sprite.character_facing * 15
            if object.hp <= 0:
                if object.type == "ROCK":
                    number = random.randint(1, 3)
                    for i in range(number):
                        x = random.randint(object.center_x - 10, object.center_x + 10)
                        y = random.randint(object.center_y - 10, object.center_y + 10)
                        item = Item("STONE", 1, x, y)
                        self.item_list.append(item)
                elif object.type == "TREE":
                    number = random.randint(1, 3)
                    for i in range(number):
                        x = random.randint(object.center_x - 10, object.center_x + 10)
                        y = random.randint(object.center_y - 10, object.center_y + 10)
                        item = Item("STICK", 1, x, y)
                        self.item_list.append(item)
                elif object.type == "GHOST":
                    number = random.randint(0, 4)
                    for i in range(number):
                        x = random.randint(int(object.center_x - 10), int(object.center_x + 10))
                        y = random.randint(int(object.center_y - 10), int(object.center_y + 10))
                        item = Item("CLOTH", 1, x, y)
                        self.item_list.append(item)
                elif object.type == "SKELETON":
                    number = random.randint(2,3)
                    for i in range(number):
                        x = random.randint(int(object.center_x - 10), int(object.center_x + 10))
                        y = random.randint(int(object.center_y - 10), int(object.center_y + 10))
                        item = Item("STONE", 1, x, y)
                        self.item_list.append(item)
                object.remove_from_sprite_lists()

    def player_damaged(self, enemy_list):
        damage_taken = enemy_list[0].damage
        self.player_sprite.hp -= damage_taken
        self.invul = 60



    def create_menu(self,type):
        self.GUI_upgrade = GUI(False, 0, arcade.load_texture("GUI_upgrade.png"), menu=True)
        self.GUI_upgrade.center_x = self.view_left + SCREEN_WIDTH/2
        self.GUI_upgrade.center_y = self.view_bottom + SCREEN_HEIGHT/2 - 20
        self.GUI_list.append(self.GUI_upgrade)

        type_list = ["AXE", "PICKAXE", "WEAPON"]
        lvl_list = [self.player_sprite.axe_lvl, self.player_sprite.pickaxe_lvl, self.player_sprite.weapon_lvl]
        for i in range(3):
            self.GUI_upgrade_icon = GUI(True, 0, type=type_list[i], menu=True, lvl=lvl_list[i])
            self.GUI_upgrade_icon.center_x = self.view_left + SCREEN_WIDTH/2 - 263 + 263 * i
            self.GUI_upgrade_icon.center_y = self.view_bottom + SCREEN_HEIGHT/2 + 90
            self.GUI_list.append(self.GUI_upgrade_icon)
        self.game_paused = True

    def upgrade_tool(self, type, GUI):
        resource_list = [self.stones, self.sticks, self.cloth]
        can_upgrade = True
        p = self.player_sprite
        if type == "PICKAXE" and p.pickaxe_lvl < len(p.pickaxe_req) - 1:
            for i in range(len(resource_list)):
                if resource_list[i] < p.pickaxe_req[p.pickaxe_lvl][i] :
                    can_upgrade = False
            if can_upgrade == True:
                self.stones -= p.pickaxe_req[p.pickaxe_lvl][0]
                self.sticks -= p.pickaxe_req[p.pickaxe_lvl][1]
                self.cloth -= p.pickaxe_req[p.pickaxe_lvl][2]
                p.pickaxe_lvl += 1
                GUI.texture = GUI.texture_dict[type][p.pickaxe_lvl]
        elif type == "AXE" and p.axe_lvl < len(p.axe_req) - 1:
            for i in range(len(resource_list)):
                if resource_list[i] < p.axe_req[p.axe_lvl][i]:
                    can_upgrade = False
            if can_upgrade == True:
                self.stones -= p.axe_req[p.axe_lvl][0]
                self.sticks -= p.axe_req[p.axe_lvl][1]
                self.cloth -= p.axe_req[p.axe_lvl][2]
                p.axe_lvl += 1
                GUI.texture = GUI.texture_dict[type][p.axe_lvl]
        elif type == "WEAPON" and p.weapon_lvl < len(p.weapon_req) - 1:
            for i in range(len(resource_list)):
                if resource_list[i] < p.weapon_req[p.weapon_lvl][i]:
                    can_upgrade = False
            if can_upgrade == True:
                self.stones -= p.weapon_req[p.weapon_lvl][0]
                self.sticks -= p.weapon_req[p.weapon_lvl][1]
                self.cloth -= p.weapon_req[p.weapon_lvl][2]
                p.weapon_lvl += 1
                GUI.texture = GUI.texture_dict[type][p.weapon_lvl]





    def delete_menu(self):
        while (self.GUI_upgrade_icon in self.GUI_list) == True or (self.GUI_upgrade in self.GUI_list) == True:
            for GUI_menu in self.GUI_list:
                if GUI_menu.menu == True:
                    GUI_menu.remove_from_sprite_lists()



    def create_preview(self, x, y, type):
        if self.preview_exists == True:
            self.delete_preview()
        else:
            self.preview_exists = True
            self.furniture_preview = Hitbox(x, y, type)
            self.hitbox_list.append(self.furniture_preview)
    def delete_preview(self):
        self.preview_exists = False
        self.furniture_preview.remove_from_sprite_lists()




    def update_view(self):
        start_x = self.view_left
        start_y = self.view_bottom
        changed = False

        # Scroll left
        left_boundary = self.view_left + VIEWPORT_MARGIN
        if self.player_sprite.left < left_boundary:
            self.view_left -= left_boundary - self.player_sprite.left
            changed = True

        # Scroll right
        right_boundary = self.view_left + SCREEN_WIDTH - VIEWPORT_MARGIN
        if self.player_sprite.right > right_boundary:
            self.view_left += self.player_sprite.right - right_boundary
            changed = True

        # Scroll up
        top_boundary = self.view_bottom + SCREEN_HEIGHT - VIEWPORT_MARGIN
        if self.player_sprite.top > top_boundary:
            self.view_bottom += self.player_sprite.top - top_boundary
            changed = True

        # Scroll down
        bottom_boundary = self.view_bottom + VIEWPORT_MARGIN
        if self.player_sprite.bottom < bottom_boundary:
            self.view_bottom -= bottom_boundary - self.player_sprite.bottom
            changed = True

        # Make sure our boundaries are integer values. While the view port does
        # support floating point numbers, for this application we want every pixel
        # in the view port to map directly onto a pixel on the screen. We don't want
        # any rounding errors.
        self.view_left = int(self.view_left)
        self.view_bottom = int(self.view_bottom)


        # If we changed the boundary values, update the view port to match
        if changed:
            change_x = self.view_left - start_x
            change_y = self.view_bottom - start_y
            arcade.set_viewport(self.view_left,
                                SCREEN_WIDTH + self.view_left,
                                self.view_bottom,
                                SCREEN_HEIGHT + self.view_bottom)

            for GUI in self.GUI_list:
                GUI.center_x += change_x
                GUI.center_y += change_y
            self.time_shader.center_x += change_x
            self.time_shader.center_y += change_y
            '''self.GUI_inventory.center_x = self.view_left + self.GUI_inventory.width/2
            self.GUI_inventory.center_y = self.view_bottom + SCREEN_HEIGHT - self.GUI_inventory.height/2
            self.GUI_toolbar.center_x = self.view_left + SCREEN_WIDTH - self.GUI_toolbar.width / 2
            self.GUI_toolbar.center_y = self.view_bottom + SCREEN_HEIGHT - self.GUI_toolbar.height / 2
            self.GUI_healthbar.center_x = self.view_left + self.GUI_healthbar.width / 2
            self.GUI_healthbar.center_y = self.view_bottom + SCREEN_HEIGHT - self.GUI_inventory.height - self.GUI_healthbar.height / 2 - 1
            for icon in self.GUI_list:
                if icon.icon == True and icon.menu == False:
                    icon.center_x = self.view_left + SCREEN_WIDTH - self.GUI_toolbar.width / 2
                    icon.center_y = self.view_bottom + icon.y'''



    def on_key_press(self, key, modifiers):
        if key == arcade.key.A:
            self.left_pressed = True
        elif key == arcade.key.D:
            self.right_pressed = True
        elif key == arcade.key.W:
            self.up_pressed = True
        elif key == arcade.key.S:
            self.down_pressed = True
        elif key == arcade.key.SPACE:
            if self.player_sprite.doing_action == False:
                terrain = arcade.check_for_collision_with_list(self.player_melee_hitbox, self.breakable_terrain_list)
                enemy = arcade.check_for_collision_with_list(self.player_melee_hitbox, self.enemy_list)
                entity_list = enemy + terrain
                if len(entity_list) > 0:
                    target = entity_list[0]
                    if target.tool_type == "WEAPON":
                        self.player_sprite.stab()
                    elif target.tool_type == "PICKAXE":
                        self.player_sprite.mine()
                    elif target.tool_type == "AXE":
                        self.player_sprite.chop()
                else:
                    self.player_sprite.punch()
        elif key == arcade.key.F:
            terrain = arcade.check_for_collision_with_list(self.player_melee_hitbox, self.terrain_list)
            if len(terrain) > 0:
                for furniture in terrain:
                    if furniture.type == "TABLE":
                        self.create_menu("TABLE")

                        break
        elif key == arcade.key.ESCAPE:
            if self.game_paused == True:
                self.delete_menu()
                self.game_paused = False
            elif self.preview_exists == True:
                self.delete_preview()
        elif key == arcade.key.T:
            print(self.player_sprite.center_x, self.player_sprite.center_y)
            self.time = 294
        elif key == arcade.key.KEY_1:
            table = Terrain("TABLE", self.mouse_hitbox.center_x, self.mouse_hitbox.center_y)
            self.impassable_terrain_list.append(table)
            self.terrain_list.append(table)
        elif key == arcade.key.KEY_2:
            ghost = Enemy("GHOST", LEFT_FACING, self.mouse_hitbox.center_x, self.mouse_hitbox.center_y)
            self.enemy_list.append(ghost)
            ghost.update_texture()
        elif key == arcade.key.KEY_3:
            self.create_projectile(self.player_sprite.center_x, self.player_sprite.center_y, self.mouse_hitbox.center_x, self.mouse_hitbox.center_y, 50, arcade.load_texture("Stone.png"))
        elif key == arcade.key.KEY_4:
            skeleton = Enemy("SKELETON", LEFT_FACING, self.mouse_hitbox.center_x, self.mouse_hitbox.center_y)
            self.enemy_list.append(skeleton)
            #physics_skeleton_wall = arcade.PhysicsEngineSimple(skeleton, self.impassable_terrain_list)
            #self.enemy_physics_list.append(physics_skeleton_wall)
            skeleton.update_texture()
            


    def on_key_release(self, key, modifiers):
        if key == arcade.key.A:
            self.left_pressed = False
        elif key == arcade.key.D:
            self.right_pressed = False
        elif key == arcade.key.W:
            self.up_pressed = False
        elif key == arcade.key.S:
            self.down_pressed = False

    def on_mouse_press(self, x: float, y: float, button: int, modifiers: int):
        if button == arcade.MOUSE_BUTTON_LEFT:
            GUI_pressed = arcade.check_for_collision_with_list(self.mouse_hitbox, self.GUI_list)

            if self.preview_exists and self.furniture_preview.can_place == True:
                furniture = Terrain(self.furniture_preview.type, self.mouse_hitbox.center_x, self.mouse_hitbox.center_y)
                self.breakable_terrain_list.append(furniture)
                self.impassable_terrain_list.append(furniture)
                self.terrain_list.append(furniture)
                p = self.furniture_preview
                self.stones -= p.stone_req
                self.sticks -= p.stick_req
                self.cloth -= p.cloth_req
                if self.cloth < p.cloth_req or self.sticks < p.stick_req or self.stones < p.stone_req:
                    self.delete_preview()
            elif len(GUI_pressed) > 0:
                for GUI in GUI_pressed:
                    if GUI.icon == True:
                        GUI_selected = GUI
                        if GUI_selected.can_be_placed == True:
                            self.create_preview(x, y, GUI_selected.type)
                        elif GUI_selected.can_be_placed == False and GUI_selected.menu == True:
                            self.upgrade_tool(GUI_selected.type, GUI_selected)
                        elif GUI_selected.can_be_placed == False:
                            type = GUI_selected.type
                            for icon in self.GUI_list:
                                if icon.icon == True:
                                    icon.load_toolbar(type)
                        break



        elif button == arcade.MOUSE_BUTTON_RIGHT:
            item = Item("STICK",1,self.view_left+x,self.view_bottom+y)
            self.item_list.append(item)
            self.cloth += 30
            self.stones += 30
            self.sticks += 30

    def on_mouse_motion(self, x: float, y: float, dx: float, dy: float):
        self.mouse_x = x
        self.mouse_y = y




def main():
    window = arcade.Window(SCREEN_WIDTH, SCREEN_HEIGHT, "survival")
    game_view = GameView()
    game_view.setup()
    window.show_view(game_view)

    arcade.run()


if __name__ == "__main__":
    main()