import random
AI_dict = {}
AI_basic = lambda mana, ammo_slots, ppl, epl, val: basic(mana, ammo_slots, ppl, epl, val)
AI_dict["BASIC"] = AI_basic
AI_defensive = lambda mana, ammo_slots, ppl, epl, val: defensive(mana, ammo_slots, ppl, epl, val)
AI_dict["DEFENSIVE"] = AI_defensive
AI_offensive = lambda mana, ammo_slots, ppl, epl, val: offensive(mana, ammo_slots, ppl, epl, val)
AI_dict["OFFENSIVE"] = AI_offensive
AI_random_spam = lambda mana, ammo_slots, ppl, epl, val: random_spam(mana, ammo_slots, ppl, epl, val)
AI_dict["RANDOMSPAM"] = AI_random_spam
AI_late_game = lambda mana, ammo_slots, ppl, epl, val: late_game(mana, ammo_slots, ppl, epl, val)
AI_dict["LATEGAME"] = AI_late_game
AI_hoarder = lambda mana, ammo_slots, ppl, epl, val: hoarder(mana, ammo_slots, ppl, epl, val)
AI_dict["HOARDER"] = AI_hoarder


def basic(mana, ammo_slots, player_projectiles, enemy_projectiles, stored_value):
    slot_output, val_output = -1, stored_value
    trajectory_output = random.randint(0, 2)
    if ammo_slots[0] != None and mana >= ammo_slots[0].mana:
        slot_output = 0
    else: pass

    return slot_output, trajectory_output, val_output

def defensive(mana, ammo_slots, player_projectile_list, enemy_projectile_list, stored_value):
    slot_output, val_output = -1, stored_value
    trajectory_output = random.randint(0, 2)
    player_projectiles = [0, 0, 0]
    for obj in player_projectile_list:
        player_projectiles[obj.trajectory] += 1
    enemy_projectiles = [0, 0, 0]
    for obj in enemy_projectile_list:
        enemy_projectiles[obj.trajectory] += 1
    for trajectory in range(2, -1, -1):
        if player_projectiles[trajectory] > enemy_projectiles[trajectory]:
            trajectory_output = trajectory
            for slot_no, ammo in enumerate(ammo_slots):
                if ammo != None:
                    if mana >= ammo.mana:
                        slot_output = slot_no
                        break
            break

    if mana == 10 and slot_output == -1 and ammo_slots[3] != None:
        slot_output = 3

    return slot_output, trajectory_output, val_output

def offensive(mana, ammo_slots, player_projectile_list, enemy_projectile_list, stored_value):
    if ammo_slots[0] != None and mana >= ammo_slots[0].mana: slot_output = 0
    else: slot_output = -1
    val_output = stored_value
    trajectory_output = 0
    player_projectiles = [0, 0, 0]
    for obj in player_projectile_list:
        player_projectiles[obj.trajectory] += 1
    enemy_projectiles = [0, 0, 0]
    for obj in enemy_projectile_list:
        enemy_projectiles[obj.trajectory] += 1
    for trajectory in range(0, 3, 1):
        if player_projectiles[trajectory] < enemy_projectiles[trajectory] or player_projectiles[trajectory] == 0:
            trajectory_output = trajectory
            for slot_no, ammo in enumerate(ammo_slots):
                if ammo != None:
                    if mana >= ammo.mana:
                        slot_output = slot_no
                        break
            break
    return slot_output, trajectory_output, val_output

def random_spam(mana, ammo_slots, player_projectiles, enemy_projectiles, stored_value):
    slot_output, val_output = -1, stored_value
    trajectory_output = random.randint(0, 2)
    for slot_no, ammo in enumerate(ammo_slots):
        if ammo != None:
            if mana >= ammo.mana:
                slot_output = slot_no
                break

    return slot_output, trajectory_output, val_output

def late_game(mana, ammo_slots, player_projectiles, enemy_projectiles, stored_value):
    slot_output, val_output = -1, stored_value
    trajectory_output = random.randint(0, 2)
    if val_output[0] == 0:
        val_output[1] = trajectory_output
        val_output[0] = 3
    elif val_output[0] > 0:
        trajectory_output = val_output[1]
        val_output[0] -= 1
    highest_mana = 0
    for slot_no, ammo in enumerate(ammo_slots):
        if ammo != None and ammo.mana >= highest_mana:
            highest_mana = ammo.mana
            slot_output = slot_no

    if mana < highest_mana:
        slot_output = -1

    return slot_output, trajectory_output, val_output

def hoarder(mana, ammo_slots, player_projectiles, enemy_projectiles, stored_value):
    slot_output, trajectory_output = -1, 0
    if stored_value[0] != 0:
        mode, timer, seq, trajectory = stored_value[0], stored_value[1], stored_value[2], stored_value[3]
    if stored_value[0] == 0: #initializer
        mode, timer, seq, trajectory = 1, 30, [], 0

    elif mode == 1: #save mana mode
        total_mana = 0
        seq = []
        not_enough_mana = 0
        for slot_no, ammo in enumerate(ammo_slots):
            if ammo == None:
                continue
            elif total_mana + ammo.mana <= 10:
                total_mana += ammo.mana
                seq.append(slot_no)
            elif total_mana + ammo.mana > 10:
                not_enough_mana += 1
        if (mana >= total_mana and len(seq) == 4) or (mana >= total_mana and not_enough_mana > 0):
            mode = 2
            trajectory = random.randint(0, 2)

    elif mode == 2: #spam mode
        timer -= 1
        if timer == 0:

            timer = 30
            if len(seq) > 0 and mana >= ammo_slots[seq[0]].mana:
                slot_output = seq[0]
                seq.remove(seq[0])
                trajectory_output = trajectory
            elif len(seq) == 0:
                mode = 1


    stored_value = [mode, timer, seq, trajectory]
    return slot_output, trajectory_output, stored_value