import arcade
from Item_Appendix import item_dict as dict, usable_dict as player_dict
from Player_Info import player_info, enemy_list, enemy_order, partner_list, game_info, temp_player_info
from AI_Scripts import AI_dict
import random
import math


SCREEN_WIDTH, SCREEN_HEIGHT = 1050, 600
Player_pos = SCREEN_WIDTH-120, SCREEN_HEIGHT/3
Enemy_pos = 120, SCREEN_HEIGHT/3
Player_Partner_pos = SCREEN_WIDTH-160, SCREEN_HEIGHT/3-60
Enemy_Partner_pos = 140, SCREEN_HEIGHT/3 -60


LEFT, RIGHT = -1, 1
y1 = lambda x: (x - Player_pos[0]) * (x - Enemy_pos[0]) * -0.0002 + Player_pos[1]
y2 = lambda x: (x - Player_pos[0]) * (x - Enemy_pos[0]) * -0.0010 + Player_pos[1]
y3 = lambda x: (x - Player_pos[0]) * (x - Enemy_pos[0]) * -0.0018 + Player_pos[1]
TRAJECTORIES = [y1, y2, y3]

class Projectile(arcade.Sprite):
    def __init__(self, type="HAMMER", traj=2, pos=Player_pos, direction=LEFT, scale=1):
        super().__init__()
        if direction == LEFT:
            mirror = False
        else: mirror = True
        stats = dict.get(type)
        self.texture = arcade.load_texture(stats[0], mirrored=mirror)
        self.dmg = stats[1]
        self.hp = stats[2]
        self.spd = stats[3]
        self.mana = stats[4]
        self.change_angle = stats[5]
        self.hit_sound = stats[6]
        self.special = stats[7]
        self.scale = scale
        self.center_x, self.center_y = pos[0], pos[1]
        self.direction = direction
        self.trajectory = traj
        self.type = type




    def update(self):
        self.center_x += (self.spd - self.trajectory * 0.1) * self.direction
        self.center_y = TRAJECTORIES[self.trajectory](self.center_x)
        self.angle += self.change_angle * self.direction * -1
        if self.special == None:
            pass
        elif self.special == "GROW" and self.scale < 1:
            self.scale += 0.05
        elif self.special == "STEALTH" and self.alpha > 0:
            self.alpha = max(0, self.alpha - 5)
        elif self.special == "EXPLOSION":
            self.alpha = max(0, self.alpha - 2)
            if self.alpha == 0:
                self.remove_from_sprite_lists()




    def update_fall(self):
        self.center_x += self.change_x
        self.center_y += self.change_y
        self.change_y = max(-9, self.change_y - 0.5)
        self.change_x *= 0.95
        self.angle += self.spd * self.direction * 5

class Partner(arcade.Sprite):
    def __init__(self, game, partner_info, position, facing=LEFT, skill="CLERIC"):
        super().__init__()
        self.FightView = game
        self.skill = skill
        self.do_action = False
        self.position = position
        self.facing = max(facing, 0)
        self.idle_textures = partner_info.get("Idle")
        self.skill_textures = partner_info.get("Idle")
        self.textures = self.idle_textures[self.facing]
        self.current_texture = 0
        self.scale = 0.8
        self.set_texture(self.current_texture)
        self.animation_ticks = 0
        if self.facing == RIGHT:
            self.alpha = 255

        self.cooldown = partner_info.get("Cooldown")
        self.timer = self.cooldown

    def update(self):
        self.timer -= 1
        self.animation_ticks += 1
        if self.timer <= 0:
            if self.skill == "CLERIC":
                self.cleric_skill()
            elif self.skill == "ARCHER":
                self.archer_skill()
            elif self.skill == "CLOWN":
                self.clown_skill()

        elif self.animation_ticks % 10 == 0:
            self.update_texture()
            self.animation_ticks = 0

    def update_texture(self):
        self.current_texture += 1
        if self.current_texture >= len(self.textures):
            if self.do_action == True:
                self.textures = self.idle_textures[self.facing]
                self.do_action = False
            self.current_texture = 0

        self.set_texture(self.current_texture)

    def archer_skill(self):
            if self.facing == 0:
                self.FightView.projectile_throw("ARROW", random.randint(0, 2), None, LEFT)
            else:
                self.FightView.projectile_throw("ARROW", random.randint(0, 2), None, RIGHT)
            self.timer = self.cooldown
    def cleric_skill(self):
        skill_pos = [Player_pos, Enemy_pos]
        list_type = [self.FightView.player_projectile_list, self.FightView.enemy_projectile_list]
        create_barrier = True
        for projectile in list_type[self.facing]:
            if projectile.type == "BARRIER":
                create_barrier = False
                break
        if create_barrier == True:
            position = skill_pos[self.facing]
            barrier = Projectile("BARRIER", 0, position, LEFT)
            barrier.alpha = 150
            barrier.scale = 0.1
            self.FightView.projectile_list.append(barrier)
            list_type[self.facing].append(barrier)
            self.timer = self.cooldown

    def clown_skill(self):
        list_type = [self.FightView.player_projectile_list, self.FightView.enemy_projectile_list]
        projectile_list = list_type[self.facing]
        if len(projectile_list) < 2:
            self.timer = self.cooldown/4
        elif len(projectile_list) >= 2:
            rng = random.sample(range(len(projectile_list)), 2)
            p1 = projectile_list[rng[0]]
            p2 = projectile_list[rng[1]]
            p1_traj, p2_traj = p1.trajectory, p2.trajectory
            p1.trajectory, p2.trajectory = p2_traj, p1_traj
            p1_x, p2_x, p1_y, p2_y = p1.center_x, p2.center_x, p1.center_y, p2.center_y
            p1.center_x, p2.center_x, p1.center_y, p2.center_y = p2_x, p1_x, p2_y, p1_y
            smoke = arcade.FadeParticle("Smoke.png", lifetime=1.5, center_xy=(p1.center_x, p1.center_y), change_xy=(0, 0))
            self.FightView.particle_list.append(smoke)
            smoke = arcade.FadeParticle("Smoke.png", lifetime=1.5, center_xy=(p2.center_x, p2.center_y), change_xy=(0, 0))
            self.FightView.particle_list.append(smoke)
            arcade.play_sound(arcade.load_sound("Smoke.wav"))
            print("swapped")


            self.timer = self.cooldown




class Character(arcade.Sprite):
    def __init__(self, character_info):
        super().__init__()
        self.texture_list = character_info.get("textures")
        self.idle_textures = self.texture_list.get("Idle")
        self.throw_textures = self.texture_list.get("Throw")
        self.textures = self.idle_textures
        self.current_texture = 0
        self.set_texture(self.current_texture)
        self.animation_ticks = 0
        self.scale = 1
        self.do_action = False

        self.stats = character_info.get("stats")
        self.hp = self.stats.get("Hp")
        self.max_hp = self.hp
        self.mana_regen = self.stats.get("Mana_Regen")
        self.max_mana = 10
        self.mana = 0
        self.throw_sound = arcade.load_sound(self.stats.get("Throw_Sound"))
        self.partner = self.stats.get("Partner")




    def update(self):
        self.animation_ticks += 1
        if self.animation_ticks % 5 == 0:
            self.update_texture()
            self.animation_ticks = 0

        if self.mana < self.max_mana:
            self.mana = min(self.max_mana, self.mana + self.mana_regen)
    def update_texture(self):
        self.current_texture += 1
        if self.current_texture >= len(self.textures):
            if self.do_action == True:
                self.textures = self.idle_textures
                self.do_action = False
            self.current_texture = 0

        self.set_texture(self.current_texture)


class GUI(arcade.Sprite):
    def __init__(self, texture):
        super().__init__()
        self.texture = texture
        self.scale = 1


class Ammo(arcade.Sprite):
    def __init__(self, type, slot_no):
        super().__init__()

        self.type = type
        stats = dict.get(type)
        self.texture = arcade.load_texture(stats[0])
        self.dmg = stats[1]
        self.hp = stats[2]
        self.spd = stats[3]
        self.mana = stats[4]
        self.change_angle = stats[5]
        self.special = stats[7]

        self.slot_no = slot_no
        self.center_x, self.center_y = SCREEN_WIDTH / 2 - 150 + (slot_no * 100), arcade.load_texture("Hand_GUI.png").height / 2 + 10

        self.start_pos = self.center_x, self.center_y


class FightView(arcade.View):
    def __init__(self, ENEMY):
        super().__init__()
        arcade.set_background_color(arcade.color.BANANA_MANIA)
        self.player_list = arcade.SpriteList()
        self.GUI_list = arcade.SpriteList()
        self.throw_GUI_list = arcade.SpriteList()
        self.ammo_list = arcade.SpriteList()
        self.projectile_list = arcade.SpriteList()
        self.enemy_projectile_list = arcade.SpriteList()
        self.player_projectile_list = arcade.SpriteList()
        self.falling_projectile_list = arcade.SpriteList()
        self.particle_list = arcade.SpriteList()

        self.last_mouse_position = 0, 0
        self.item_chosen = None
        self.ammo_slots = [None, None, None, None]
        self.restock_counter = 60
        self.restock_counter_limit = 60
        self.enemy_ammo_slots = self.ammo_slots.copy()
        self.enemy_restock_counter = 60
        self.enemy_type = ENEMY

        self.number_textures = arcade.load_spritesheet("Numerals.png", 12, 31, 11, 11)







    def setup(self):
        self.mouse = GUI(arcade.load_texture("Mouse_Hitbox.png"))
        self.mouse.alpha = 0
        self.mouse.center_x, self.mouse.center_y = 50, 50
        self.player_list.append(self.mouse)
        x = 3/5 * SCREEN_WIDTH
        for i in range(3):
            x += 10
            icon = GUI(arcade.load_texture("Insert.png"))
            icon.position = x, TRAJECTORIES[i](x)
            icon.traj = i
            icon.alpha = 150
            self.GUI_list.append(icon)
            self.throw_GUI_list.append(icon)


        player_hand = GUI(arcade.load_texture("Hand_GUI.png"))
        player_hand.position = SCREEN_WIDTH/2, player_hand.height/2
        self.GUI_list.append(player_hand)

        pending_hand = GUI(arcade.load_texture("Pending_GUI.png"))
        pending_hand.position = 0.5 * (SCREEN_WIDTH + player_hand.width + pending_hand.width), pending_hand.height/2
        self.GUI_list.append(pending_hand)

        self.player_deck = temp_player_info.get("deck")
        ammo = self.player_deck[random.randint(0, len(self.player_deck)-1)]
        self.pending_ammo = GUI(arcade.load_texture(dict.get(ammo)[0]))
        self.pending_ammo.scale = 0.64
        self.pending_ammo.position = pending_hand.position
        self.pending_ammo.type = ammo
        self.GUI_list.append(self.pending_ammo)

        self.load_ammo = GUI(arcade.load_texture("Loading_GUI.png"))
        self.load_ammo.scale = 1
        self.load_ammo.position = self.pending_ammo.position
        self.load_ammo.fixed_height = self.load_ammo.height
        self.load_ammo.fixed_y = self.load_ammo.center_y
        self.load_ammo.alpha = 150
        self.GUI_list.append(self.load_ammo)



        self.player = Character(temp_player_info)
        self.player.position = Player_pos
        self.player_list.append(self.player)

        healthbar = GUI(arcade.load_texture("GUI_healthbar.png"))
        healthbar.position = SCREEN_WIDTH - healthbar.width/2, SCREEN_HEIGHT - healthbar.height/2
        self.GUI_list.append(healthbar)

        self.player_health = GUI(arcade.load_texture("GUI_health.png"))
        self.player_health.position = healthbar.position
        self.player_health.fixed_x, self.player_health.fixed_width = self.player_health.center_x, self.player_health.width
        self.GUI_list.append(self.player_health)

        x,y = SCREEN_WIDTH - healthbar.width/2 , SCREEN_HEIGHT - healthbar.height - arcade.load_texture("GUI_manabar.png").height/2
        self.player_mana = GUI(arcade.load_texture("GUI_mana.png"))
        self.player_mana.position = x, y
        self.player_mana.fixed_x, self.player_mana.fixed_width = x, self.player_mana.width
        self.GUI_list.append(self.player_mana)

        manabar = GUI(arcade.load_texture("GUI_manabar.png"))
        manabar.position = self.player_mana.position
        self.GUI_list.append(manabar)

        self.mana_slots = []
        for i in range(4):
            mana_req = GUI(self.number_textures[10])
            mana_req.position = SCREEN_WIDTH / 2 - 155 + (i * 100), 15
            mana_req.scale = 0.8
            self.GUI_list.append(mana_req)
            self.mana_slots.append(mana_req)
            mana_ball = GUI(arcade.load_texture("Mana_Ball.png"),)
            mana_ball.position = SCREEN_WIDTH / 2 - 140 + (i * 100), 15
            mana_ball.scale = 0.2
            self.GUI_list.append(mana_ball)





        if self.player.partner != None:
            self.player_partner = Partner(self, partner_list.get(self.player.partner), Player_Partner_pos, LEFT, self.player.partner)
            self.player_list.append(self.player_partner)



        enemy_chosen = enemy_list.get(self.enemy_type)
        self.enemy_deck = enemy_chosen.get("deck")
        ai = enemy_chosen.get("stats").get("AI")
        self.AI_chosen = AI_dict.get(ai)
        self.AI_stored_val = [0, 0]



        self.enemy = Character(enemy_chosen)
        self.enemy.position = Enemy_pos
        self.player_list.append(self.enemy)

        healthbar = GUI(arcade.load_texture("GUI_healthbar.png"))
        healthbar.position = healthbar.width / 2, SCREEN_HEIGHT - healthbar.height / 2
        self.GUI_list.append(healthbar)

        self.enemy_health = GUI(arcade.load_texture("GUI_health.png"))
        self.enemy_health.position = healthbar.position
        self.enemy_health.fixed_x, self.enemy_health.fixed_width = self.enemy_health.center_x, self.enemy_health.width
        self.GUI_list.append(self.enemy_health)

        if self.enemy.partner != None:
            self.enemy_partner = Partner(self, partner_list.get(self.enemy.partner), Enemy_Partner_pos, RIGHT,
                                          self.enemy.partner)
            self.player_list.append(self.enemy_partner)


    def projectile_throw(self, type="HAMMER", traj=0, special=None, direction=LEFT):
        normal_throw = False
        x = max(0, direction)
        position_list = [Player_pos, Enemy_pos]
        character_list = [self.player, self.enemy]
        projectile_lists = [self.player_projectile_list, self.enemy_projectile_list]
        pos, player, p_list = position_list[x], character_list[x], projectile_lists[x]
        if special == None:
            normal_throw = True
        elif special == "MULTISHOT":
            arcade.play_sound(player.throw_sound)
            for new_traj in range(3):
                projectile = Projectile(type, new_traj, pos, direction)
                self.projectile_list.append(projectile)
                p_list.append(projectile)
        else:
            normal_throw = True

        if normal_throw == True:
            projectile = Projectile(type, traj, pos, direction)
            self.projectile_list.append(projectile)
            p_list.append(projectile)
            arcade.play_sound(player.throw_sound)

        if special == "STEALTH":
            position = projectile.center_x + 20 * direction, projectile.center_y + 10
            smoke = arcade.FadeParticle("Smoke.png", lifetime=0.5, center_xy=(position), change_xy=(0, 0))
            smoke.scale = 0.8
            self.particle_list.append(smoke)
            arcade.play_sound(arcade.load_sound("Smoke.wav"))
        elif special == "MASSIVE":
            projectile.scale = 3
        player.do_action = True
        player.current_texture = 0
        player.set_texture(0)
        player.textures = player.throw_textures


    def check_collision(self, p1, p2):
        kill_p1, kill_p2 = False, False
        while (p1.hp > 0) and (p2.hp > 0):
            p1.hp -= p2.dmg
            p2.hp -= p1.dmg



        if p1.hp <= 0: kill_p1 = True
        if p2.hp <= 0: kill_p2 = True

        if kill_p1: self.kill(p1)
        if kill_p2: self.kill(p2)

    def player_hit(self, hit_list):
        for obj in hit_list:
            self.player.hp -= obj.dmg
            number = list(str(obj.dmg))
            if obj.dmg != 0:
                for x, num in enumerate(number):
                    texture = self.number_textures[int(num)]
                    damage_particle = arcade.FadeParticle(texture,change_xy=(0, 0.1), center_xy=(obj.center_x-15+30*x, obj.center_y), lifetime=1.5)
                    damage_particle.can_reap()
                    self.particle_list.append(damage_particle)
            self.kill(obj)
        if self.player.hp <= 0:
            game_info[1] += 1
            save_game()
            defeat_view = DefeatView()
            window.show_view(defeat_view)
    def enemy_hit(self, hit_list):
        for obj in hit_list:
            self.enemy.hp -= obj.dmg
            number = list(str(obj.dmg))
            if obj.dmg != 0:
                for x, num in enumerate(number):
                    texture = self.number_textures[int(num)]
                    damage_particle = arcade.FadeParticle(texture, change_xy=(0, 0.1),
                                                              center_xy=(obj.center_x + 26 * x, obj.center_y), lifetime=1.5)
                    self.particle_list.append(damage_particle)
            self.kill(obj)
        if self.enemy.hp <= 0:
            game_info[1] += 10
            save_game()
            victory_view = VictoryView()
            window.show_view(victory_view)
    def kill(self,obj):
        x = max(0, obj.direction)
        lists =[self.player_projectile_list,self.enemy_projectile_list]

        normal_death = False
        if obj.special == None:
            normal_death = True
        elif obj.special == "STEALTH":
            obj.alpha = 255
            normal_death = True
        elif obj.special == "EXPLODE":
            explosion = Projectile("EXPLOSION", obj.trajectory, obj.position, obj.direction)
            explosion.scale = 3
            self.enemy_projectile_list.append(explosion)
            self.player_projectile_list.append(explosion)
            self.projectile_list.append(explosion)
            obj.remove_from_sprite_lists()
            arcade.play_sound(arcade.load_sound("Explosion.wav"))

        elif obj.special == "EXPLOSION":
            obj.dmg = 0
        else:
            normal_death = True

        if normal_death == True:
            try: lists[x].remove(obj)
            except: pass
            obj.change_x, obj.change_y = -obj.direction * obj.spd, obj.spd
            self.falling_projectile_list.append(obj)
            arcade.play_sound(obj.hit_sound)

    def restock_ammo(self):
        if self.restock_counter > 0:
            self.load_ammo.height = self.restock_counter/self.restock_counter_limit * self.load_ammo.fixed_height
            self.load_ammo.center_y = self.load_ammo.fixed_y - self.load_ammo.fixed_height/2 + self.load_ammo.height/2
            self.restock_counter -= 1

        elif None in self.ammo_slots and self.restock_counter == 0:
            self.restock_counter = 60

            type = self.pending_ammo.type
            for slot_no in range(0, 4):
                if self.ammo_slots[slot_no] == None:

                    ammo = Ammo(type, slot_no)
                    self.ammo_slots[slot_no] = ammo
                    self.GUI_list.append(ammo)
                    self.ammo_list.append(ammo)
                    self.mana_slots[slot_no].texture = self.number_textures[ammo.mana]
                    break

            rng = random.randrange(0, len(self.player_deck))
            new_type = self.player_deck[rng]
            new_texture = dict.get(new_type)[0]
            self.pending_ammo.texture = arcade.load_texture(new_texture)
            self.pending_ammo.type = new_type

        if self.enemy_restock_counter > 0:
            self.enemy_restock_counter -= 1
        elif None in self.enemy_ammo_slots and self.enemy_restock_counter == 0:
            self.enemy_restock_counter = 60
            for enemy_slot_no in range(0, 4):
                if self.enemy_ammo_slots[enemy_slot_no] == None:
                    rng = random.randrange(0, len(self.enemy_deck))
                    type = self.enemy_deck[rng]
                    ammo = Ammo(type, enemy_slot_no)
                    self.enemy_ammo_slots[enemy_slot_no] = ammo
                    break




    def update(self, delta_time= int):
        self.enemy_projectile_list.update()
        self.player_list.update()
        self.particle_list.update()
        for projectile in self.player_projectile_list:
            projectile.update()
            hit_list = arcade.check_for_collision_with_list(projectile, self.enemy_projectile_list)
            if len(hit_list) > 0:
                for hit_projectile in hit_list:
                    self.check_collision(projectile, hit_projectile)

        for obj in self.falling_projectile_list:
            obj.update_fall()

        for obj in self.projectile_list:
            if obj.center_y < -100 or obj.center_x < -100 or obj.center_x > SCREEN_WIDTH + 100:
                obj.remove_from_sprite_lists()


        hit_list = arcade.check_for_collision_with_list(self.player, self.enemy_projectile_list)
        if len(hit_list) > 0:
            self.player_hit(hit_list)
        hit_list = arcade.check_for_collision_with_list(self.enemy, self.player_projectile_list)
        if len(hit_list) > 0:
            self.enemy_hit(hit_list)

        self.restock_ammo()
        self.update_statbars()
        self.enemy_ai()



    def update_statbars(self):
        self.player_health.width = max(self.player.hp/self.player.max_hp * self.player_health.fixed_width, 0)
        self.player_health.center_x = self.player_health.fixed_x - self.player_health.fixed_width/2 + self.player_health.width/2
        self.player_mana.width = max(self.player.mana / self.player.max_mana * self.player_mana.fixed_width, 0)
        self.player_mana.center_x = self.player_mana.fixed_x - self.player_mana.fixed_width/2 + self.player_mana.width / 2
        self.enemy_health.width = max(self.enemy.hp / self.enemy.max_hp * self.enemy_health.fixed_width, 0)
        self.enemy_health.center_x = self.enemy_health.fixed_x - self.enemy_health.fixed_width / 2 + self.enemy_health.width / 2

    def enemy_ai(self):
        if self.enemy_ammo_slots == [None, None, None, None]:
            pass
        else:
            output = self.AI_chosen(self.enemy.mana, self.enemy_ammo_slots, self.player_projectile_list,
                                 self.enemy_projectile_list, self.AI_stored_val)
            item_chosen = self.enemy_ammo_slots[output[0]]
            trajectory_chosen = output[1]
            self.AI_stored_val = output[2]
            if output[0] == -1:
                pass
            else:
                self.projectile_throw(item_chosen.type, trajectory_chosen, item_chosen.special, RIGHT)
                self.enemy.mana -= item_chosen.mana
                self.enemy_ammo_slots[output[0]] = None






    def on_draw(self):
        arcade.start_render()
        for projectile in self.projectile_list:
            if projectile.center_y > Player_pos[1] - self.player.height/3:
                arcade.draw_scaled_texture_rectangle(projectile.center_x, Player_pos[1] - self.player.height/3,
                                                     arcade.load_texture("Shadow.png"), projectile.center_y/SCREEN_HEIGHT)

        self.projectile_list.draw()
        self.GUI_list.draw()
        self.player_list.draw()
        self.particle_list.draw()



    def on_mouse_press(self, x: float, y: float, button: int, modifiers: int):
        if button == arcade.MOUSE_BUTTON_LEFT:
            ammo_hit = arcade.check_for_collision_with_list(self.mouse, self.ammo_list)
            if len(ammo_hit) > 0:
                self.item_chosen = ammo_hit[0]
        elif button == arcade.MOUSE_BUTTON_MIDDLE:
            self.player_partner.clown_skill()







    def on_mouse_release(self, x: float, y: float, button: int, modifiers: int):
        if button == arcade.MOUSE_BUTTON_LEFT and self.item_chosen is not None:
            dest_list = arcade.check_for_collision_with_list(self.mouse, self.throw_GUI_list)
            if len(dest_list) > 0:
                if self.player.mana >= self.item_chosen.mana:
                    self.player.mana -= self.item_chosen.mana
                    selected_icon = dest_list[0]
                    self.projectile_throw(self.item_chosen.type, selected_icon.traj, self.item_chosen.special, LEFT)
                    self.ammo_slots[self.item_chosen.slot_no] = None
                    self.mana_slots[self.item_chosen.slot_no].texture = self.number_textures[10]
                    self.item_chosen.remove_from_sprite_lists()
                elif self.player.mana < self.item_chosen.mana:
                    self.item_chosen.position = self.item_chosen.start_pos
            elif len(dest_list) == 0:
                self.item_chosen.position = self.item_chosen.start_pos
            self.item_chosen = None



    def on_mouse_motion(self, x: float, y: float, dx: float, dy: float):
        self.last_mouse_position = x, y
        self.mouse.position = self.last_mouse_position
        if self.item_chosen is not None:
            self.item_chosen.position = self.last_mouse_position

    def on_key_press(self, symbol: int, modifiers: int):
        if symbol == arcade.key.KEY_2:
            self.projectile_throw("CHAINBOLA", 0, "MULTISHOT", LEFT)
        elif symbol == arcade.key.KEY_1:
            self.projectile_throw("CHAINBOLA", 0, "MULTISHOT", RIGHT)




class VictoryView(arcade.View):
    def __init__(self):
        super().__init__()
        arcade.set_background_color(arcade.color.DARK_SPRING_GREEN)
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)
        nextlvl_button = Main_Button(self, x=SCREEN_WIDTH/2, y=SCREEN_HEIGHT *3/5, theme=self.theme,
                                            text="Next level", task="NEXT_LVL",
                                            width=300, height=50)
        self.button_list.append(nextlvl_button)
        main_menu_button = Main_Button(self, x=SCREEN_WIDTH / 2, y=SCREEN_HEIGHT * 3 / 5 - 80, theme=self.theme,
                                          text="Main Menu", task="MENU",
                                          width=300, height=50)
        self.button_list.append(main_menu_button)



    def on_draw(self):
        arcade.start_render()
        super().on_draw()

        arcade.draw_text("VICTORY!", SCREEN_WIDTH / 2, SCREEN_HEIGHT * 3 / 4,
                         arcade.color.YELLOW_ROSE, font_size=40, anchor_x="center", anchor_y="center",
                         bold=True)
        w, h = arcade.load_texture("Coin.png").width, arcade.load_texture("Coin.png").height
        arcade.draw_lrwh_rectangle_textured(0, SCREEN_HEIGHT - h, w, h, arcade.load_texture("Coin.png"))
        arcade.draw_text(f"{game_info[1]}", w + 10, SCREEN_HEIGHT - h / 2, arcade.color.BLACK, font_size=30, anchor_x="left",
                         anchor_y="center")
class DefeatView(arcade.View):
    def __init__(self):
        super().__init__()
        arcade.set_background_color(arcade.color.BLACK_BEAN)
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)
        nextlvl_button = Main_Button(self, x=SCREEN_WIDTH / 2, y=SCREEN_HEIGHT * 3 / 5, theme=self.theme,
                                     text="Retry", task="QUICKPLAY",
                                     width=300, height=50)
        self.button_list.append(nextlvl_button)
        main_menu_button = Main_Button(self, x=SCREEN_WIDTH / 2, y=SCREEN_HEIGHT * 3 / 5 - 80, theme=self.theme,
                                       text="Main Menu", task="MENU",
                                       width=300, height=50)
        self.button_list.append(main_menu_button)



    def on_draw(self):
        arcade.start_render()
        super().on_draw()

        arcade.draw_text("DEFEAT...", SCREEN_WIDTH / 2, SCREEN_HEIGHT * 3 / 4,
                         arcade.color.CRIMSON, font_size=40, anchor_x="center", anchor_y="center",
                         bold=True)
        w, h = arcade.load_texture("Coin.png").width, arcade.load_texture("Coin.png").height
        arcade.draw_lrwh_rectangle_textured(0, SCREEN_HEIGHT - h, w, h, arcade.load_texture("Coin.png"))
        arcade.draw_text(f"{game_info[1]}", w + 10, SCREEN_HEIGHT - h / 2, arcade.color.BLACK, font_size=30, anchor_x="left",
                         anchor_y="center")
class MenuView(arcade.View):
    def __init__(self):
        super().__init__()
        arcade.set_background_color(arcade.color.AUROMETALSAURUS)
        #self.mouse = arcade.Sprite("Mouse_Hitbox.png", scale=0.5)
        #self.mouse.alpha = 0
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)
        self.font_size = 40
        self.font_change = lambda ticks: 5*math.sin(0.1*ticks) + 40
        self.font_ticks = 0

    def setup(self):
        self.quickplay_button = Main_Button(self, x=SCREEN_WIDTH/2, y=SCREEN_HEIGHT *3/5, theme=self.theme,
                                            text=f"Quickplay - lvl {game_info[0] + 1}", task="QUICKPLAY",
                                            width=300, height=50)
        self.button_list.append(self.quickplay_button)
        edit_button = Main_Button(self, x=SCREEN_WIDTH/2, y=SCREEN_HEIGHT *3/5 - 70, theme=self.theme,
                                            text="Edit Deck", task="EDIT",
                                            width=300, height=50)
        self.button_list.append(edit_button)
        x, y = self.quickplay_button.center_x + self.quickplay_button.width/2, self.quickplay_button.center_y
        inc_lvl_button = Toggle_Button(self, width=50, height=self.quickplay_button.height/2, theme=self.theme, text="+", task="LVL+1")
        inc_lvl_button.center_x, inc_lvl_button.center_y = x + inc_lvl_button.width/2, y + inc_lvl_button.height/2
        self.button_list.append(inc_lvl_button)
        dec_lvl_button = Toggle_Button(self, width=50, height=self.quickplay_button.height / 2, theme=self.theme, text="-",task="LVL-1")
        dec_lvl_button.center_x, dec_lvl_button.center_y = x + dec_lvl_button.width / 2, y - dec_lvl_button.height / 2
        self.button_list.append(dec_lvl_button)

    def on_draw(self):
        arcade.start_render()
        #self.mouse.draw()
        super().on_draw()

        arcade.draw_text("Throwing Wars", SCREEN_WIDTH/2, SCREEN_HEIGHT * 3/4,
                         arcade.color.YELLOW_ROSE, font_size=self.font_size, anchor_x="center", anchor_y="center", bold=True)
        w, h = arcade.load_texture("Coin.png").width, arcade.load_texture("Coin.png").height
        arcade.draw_lrwh_rectangle_textured(0, SCREEN_HEIGHT - h, w, h, arcade.load_texture("Coin.png"))
        arcade.draw_text(f"{game_info[1]}",w+10,SCREEN_HEIGHT-h/2, arcade.color.BLACK, font_size=30, anchor_x="left", anchor_y="center")

    def update(self, delta_time=float):
        self.font_ticks += 0.8
        self.font_size = self.font_change(self.font_ticks)

class Edit_Deck(arcade.View):
    def __init__(self):
        super().__init__()
        self.deck_minimum = 20
        self.ammo_limit = 4
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)

        self.inventory_theme = arcade.Theme()
        self.inventory_theme.set_font(10, arcade.color.RICH_BLACK)
        normal = "Inventory_Bar_GUI.png"
        self.inventory_theme.add_button_textures(normal)

        self.GUI_list = arcade.SpriteList()
        self.inventory_list = []
        self.ammo_list = []

        self.create_inventory_GUI()

        border = GUI(arcade.load_texture("Edit_Deck_GUI.png"))
        border.position = SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2
        self.GUI_list.append(border)

        add_button = Toggle_Button(self, SCREEN_WIDTH * 0.9, SCREEN_HEIGHT/2 + 53, 77, 30, "+", self.theme, "ADD_AMMO")
        self.button_list.append(add_button)
        remove_button = Toggle_Button(self, SCREEN_WIDTH * 0.9, SCREEN_HEIGHT / 2 - 53, 77, 30, "-", self.theme,"REMOVE_AMMO")
        self.button_list.append(remove_button)
        item_slot = arcade.Sprite("Ammo_Selected.png", center_x=SCREEN_WIDTH * 0.9, center_y= SCREEN_HEIGHT/2)
        self.GUI_list.append(item_slot)
        self.deck_size = 0

        for ammo in self.ammo_list:
            self.deck_size += ammo.count
        self.ammo_count_display = Toggle_Button(self, SCREEN_WIDTH * 0.9, 150, 200, 40, "%i/%i"%(self.deck_size, self.deck_minimum), self.theme)
        self.button_list.append(self.ammo_count_display)

        self.item_selected = arcade.Sprite(self.inventory_list[0].texture, center_x=SCREEN_WIDTH * 0.9, center_y= SCREEN_HEIGHT/2, scale=0.9)
        self.GUI_list.append(self.item_selected)
        self.item_selected.type = self.inventory_list[0].type

        menu_button = Main_Button(self, SCREEN_WIDTH * 0.11, 50, 200, 40, "Main Menu", self.theme, "MENU")
        self.button_list.append(menu_button)
        save_deck_button = Toggle_Button(self, SCREEN_WIDTH * 0.11, 100, 200, 40, "Save deck", self.theme, "SAVE_DECK")
        self.button_list.append(save_deck_button)
        reload_deck_button = Toggle_Button(self, SCREEN_WIDTH * 0.11, 150, 200, 40, "Reset deck", self.theme, "RELOAD_DECK")
        self.button_list.append(reload_deck_button)
    def reset_inventory_GUI(self):
        for obj in self.inventory_list:
            obj.center_y = obj.min_y
            if obj.type != None:
                obj.count = temp_player_info.get("deck").count(obj.type)
                obj.text = "ATK:%s  HP:%s  " \
                           "SPD:%s  MANA:%s                COUNT:%s" % (obj.dmg, obj.hp, obj.spd, obj.mana, obj.count)
        deck_size = 0
        for ammo in self.ammo_list:
            deck_size += ammo.count
        self.update_count(deck_size - self.deck_size)

    def create_inventory_GUI(self):
        for y, obj in enumerate(player_dict):
            count = temp_player_info.get("deck").count(obj)
            stats = player_dict.get(obj)
            texture, dmg, hp ,spd, mana= stats[0], stats[1], stats[2], stats[3], stats[4]
            item_button = Toggle_Button(self, SCREEN_WIDTH/2, SCREEN_HEIGHT - 70 - y*52, 500, 52,
                                        "ATK:%s  HP:%s  "
                                        "SPD:%s  MANA:%s                COUNT:%s"%(dmg, hp, spd, mana, count),
                                        self.inventory_theme, "SELECT")
            item_button.min_y, item_button.max_y = item_button.center_y, item_button.center_y + len(player_dict) * item_button.height - 512
            item_button.type, item_button.texture, item_button.dmg, item_button.hp, item_button.spd, item_button.mana , item_button.count = obj, texture, dmg, hp ,spd, mana, count
            self.button_list.append(item_button)
            self.inventory_list.append(item_button)
            self.ammo_list.append(item_button)

            item_icon = arcade.Sprite(texture)
            item_icon.position = item_button.center_x - item_button.width/2 + item_icon.width/2, item_button.center_y
            item_icon.scale, item_icon.type = 2/3, None
            item_icon.max_y, item_icon.min_y = item_button.max_y, item_button.min_y
            self.GUI_list.append(item_icon)
            self.inventory_list.append(item_icon)
    def update_count(self, change):
        self.deck_size += change
        self.ammo_count_display.text = f"{self.deck_size}/{self.deck_minimum}"
        if self.deck_size < self.deck_minimum:self.ammo_count_display.font_color = arcade.color.RED_DEVIL
        else:self.ammo_count_display.font_color = arcade.color.WHITE
    def save_deck(self):
        edited_deck = []
        for ammo in self.ammo_list:
            for count in range(ammo.count):
                edited_deck.append(ammo.type)
        if len(edited_deck) >= self.deck_minimum:
            temp_player_info["deck"] = edited_deck
            save_game()
            print("deck saved")
        elif len(edited_deck) <= self.deck_minimum:
            print("you need more ammo!")

    def on_draw(self):
        arcade.start_render()
        super().on_draw()
        self.GUI_list.draw()

    def on_mouse_scroll(self, x: int, y: int, scroll_x: int, scroll_y: int):
        if scroll_y != 0:
            for obj in self.inventory_list:
                obj.center_y = max(min(obj.center_y - scroll_y * 30, obj.max_y), obj.min_y)



class Toggle_Button(arcade.TextButton):
    def __init__(self, game, x=0, y=0, width=1, height=1, text="TEXT", theme=None, task=None):
        super().__init__(x, y, width, height, text, theme=theme)
        self.game = game
        self.task = task

    def on_press(self):

        if self.task == "LVL+1":
            game_info[0] = min(len(enemy_order)-1, game_info[0] + 1)
            self.game.quickplay_button.text = f"Quickplay - lvl {game_info[0] + 1}"
        elif self.task == "LVL-1":
            game_info[0] = max(0, game_info[0]-1)
            self.game.quickplay_button.text = f"Quickplay - lvl {game_info[0] + 1}"
        elif self.task == "SELECT":
            self.game.item_selected.texture = arcade.load_texture(dict.get(self.type)[0])
            self.game.item_selected.type = self.type
        elif self.task == "ADD_AMMO" or self.task == "REMOVE_AMMO":
            for obj in self.game.ammo_list:
                if obj.type == self.game.item_selected.type:
                    old_count = obj.count
                    if self.task == "ADD_AMMO":
                        obj.count = min(self.game.ammo_limit, obj.count + 1)
                    elif self.task == "REMOVE_AMMO":
                        obj.count = max(0, obj.count - 1)
                    self.game.update_count(obj.count - old_count)
                    obj.text = "ATK:%s  HP:%s  "\
                               "SPD:%s  MANA:%s                COUNT:%s"%(obj.dmg, obj.hp, obj.spd, obj.mana, obj.count)
                    break
        elif self.task == "SAVE_DECK":
            self.game.save_deck()
        elif self.task == "RELOAD_DECK":
            self.game.reset_inventory_GUI()








class Main_Button(arcade.TextButton):
    def __init__(self, game, x=SCREEN_WIDTH/2, y=500, width=300, height=50, text="TEXT", theme=None, task=None):
        super().__init__(x, y, width, height, text, theme=theme)
        self.game = game
        self.task = task


    def on_press(self):
        if self.task == "QUICKPLAY":
            enemy_chosen = enemy_order[game_info[0]]
            game_view = FightView(enemy_chosen)
            game_view.setup()
            window.show_view(game_view)
        elif self.task == "NEXT_LVL":
            game_info[0] = min(len(enemy_order)-1, game_info[0] + 1)
            enemy_chosen = enemy_order[game_info[0]]
            game_view = FightView(enemy_chosen)
            game_view.setup()
            window.show_view(game_view)
        elif self.task == "MENU":
            menu_view = MenuView()
            menu_view.setup()
            window.show_view(menu_view)
        elif self.task == "EDIT":
            edit_view = Edit_Deck()
            window.show_view(edit_view)
        elif  self.task == "SAVE":
            save_game()


def save_game():
    temp_deck = temp_player_info.get("deck")
    temp_partner = temp_player_info.get("stats").get("Partner")
    if temp_partner != None:
        temp_partner = '"' + temp_partner + '"'

    f = open("Save_File.py", "w+")
    f.write('import arcade\n\n'
            f'money = {game_info[1]}\n'
            'player_deck = %s\n'
            'player_textures = {"Idle":arcade.load_spritesheet("Player_Idle_Mirrored.png", 50, 136, 7, 14),\n'
            '                   "Throw":arcade.load_spritesheet("Player_Throw_Mirrored.png", 70, 136, 3, 3)}\n'
            'player_stats = {"Hp": 20, "Mana_Regen": 0.02, "Throw_Sound": "Player_Throwsound.wav", "Partner": %s}\n\n'


            'player_info = {"deck": player_deck, "textures": player_textures, "stats": player_stats}'
            %(temp_deck, temp_partner))
    f.close()

def main():
    global window
    window = arcade.Window(SCREEN_WIDTH, SCREEN_HEIGHT, "throwing wars")
    menu_view = MenuView()
    menu_view.setup()
    window.show_view(menu_view)

    arcade.run()



if __name__ == "__main__":
    main()