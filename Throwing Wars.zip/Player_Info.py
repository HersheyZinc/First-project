import arcade
from Save_File import player_info, money

level = 0
#level, temp_money
game_info = [level, money]



temp_player_info = player_info


enemy_list = {}

enemy_deck = ["CRATE", "CRATE", "ARROW", "SWORD"]
enemy_textures = {"Idle": arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14),
                   "Throw": arcade.load_spritesheet("Player_Throw.png", 70, 136, 3, 3)}
enemy_stats = {"Hp": 10, "Mana_Regen": 0.015, "Throw_Sound": "Player_Throwsound.wav", "Partner": None, "AI": "BASIC"}

basic1_info = {"deck": enemy_deck, "textures": enemy_textures, "stats": enemy_stats}
enemy_list["Enemy1"] = basic1_info



enemy_deck = ["ARROW", "ARROW", "ARROW", "ARROW", "SHIELD", "SHIELD", "KNIFE", "KNIFE", "SAWBLADE"]
enemy_textures = {"Idle": arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14),
                   "Throw": arcade.load_spritesheet("Player_Throw.png", 70, 136, 3, 3)}
enemy_stats = {"Hp": 15, "Mana_Regen": 0.016, "Throw_Sound": "Archer_Throwsound.wav", "Partner": None, "AI": "OFFENSIVE"}

archer1_info = {"deck": enemy_deck, "textures": enemy_textures, "stats": enemy_stats}
enemy_list["Enemy2"] = archer1_info


enemy_deck = ["HAMMER", "HAMMER", "HAMMER", "SWORD", "SWORD", "SHIELD"]
enemy_textures = {"Idle": arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14),
                   "Throw": arcade.load_spritesheet("Player_Throw.png", 70, 136, 3, 3)}
enemy_stats = {"Hp": 20, "Mana_Regen": 0.017, "Throw_Sound": "Archer_Throwsound.wav", "Partner": None, "AI": "DEFENSIVE"}

basic2_info = {"deck": enemy_deck, "textures": enemy_textures, "stats": enemy_stats}
enemy_list["Enemy3"] = basic2_info


cannon_deck = ["CANNONBALL", "CRATE", "SHIELD", "HAMMER", "SWORD"]
cannon_textures = {"Idle": arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14),
                   "Throw": arcade.load_spritesheet("Player_Throw.png", 70, 136, 3, 3)}
cannon_stats = {"Hp": 20, "Mana_Regen": 0.018, "Throw_Sound": "Cannon.wav", "Partner": None, "AI": "DEFENSIVE"}

cannon1_info = {"deck": cannon_deck, "textures": cannon_textures, "stats": cannon_stats}
enemy_list["Enemy4"] = cannon1_info


chef_deck = ["BOWL", "BOWL", "CUP", "CUP", "FISH", "FISH", "STEAK", "KNIFE"]
chef_textures = {"Idle": arcade.load_spritesheet("Chef_Idle.png", 50, 155, 4, 8),
                   "Throw": arcade.load_spritesheet("Chef_Throw.png", 70, 155, 4, 4)}
chef_stats = {"Hp": 20, "Mana_Regen": 0.019, "Throw_Sound": "Player_Throwsound.wav", "Partner": None, "AI": "RANDOMSPAM"}

chef1_info = {"deck": chef_deck, "textures": chef_textures, "stats": chef_stats}
enemy_list["Enemy5"] = chef1_info


enemy_deck = ["BALL", "BALL", "HAMMER", "DISGUISE", "SAWBLADE", "JUGGLINGBALL"]
enemy_textures = {"Idle": arcade.load_spritesheet("Clown_Idle.png", 50, 150, 2, 6),
                   "Throw": arcade.load_spritesheet("Clown_Idle.png", 50, 150, 2, 6)}
enemy_stats = {"Hp": 20, "Mana_Regen": 0.019, "Throw_Sound": "Clown_Throwsound.mp3", "Partner": "CLOWN", "AI": "BASIC"}

clown1_info = {"deck": enemy_deck, "textures": enemy_textures, "stats": enemy_stats}
enemy_list["Enemy6"] = clown1_info


cannon_deck = ["CANNONBALL", "CANNONBALL", "MULTISHOT"]
cannon_textures = {"Idle": arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14),
                   "Throw": arcade.load_spritesheet("Player_Throw.png", 70, 136, 3, 3)}
cannon_stats = {"Hp": 20, "Mana_Regen": 0.019, "Throw_Sound": "Cannon.wav", "Partner": "CLERIC", "AI": "OFFENSIVE"}

cannon2_info = {"deck": cannon_deck, "textures": cannon_textures, "stats": cannon_stats}
enemy_list["Enemy7"] = cannon2_info


enemy_deck = ["BALL", "DISGUISE", "SAWBLADE", "JUGGLINGBALL", "JUGGLINGBALL", "JUGGLINGPIN"]
enemy_textures = {"Idle": arcade.load_spritesheet("Clown_Idle.png", 50, 150, 2, 6),
                   "Throw": arcade.load_spritesheet("Clown_Idle.png", 50, 150, 2, 6)}
enemy_stats = {"Hp": 20, "Mana_Regen": 0.019, "Throw_Sound": "Clown_Throwsound.mp3", "Partner": "CLOWN", "AI": "HOARDER"}

clown2_info = {"deck": enemy_deck, "textures": enemy_textures, "stats": enemy_stats}
enemy_list["Enemy8"] = clown2_info


enemy_deck = ["ARROW", "ARROW"]
enemy_textures = {"Idle": arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14),
                   "Throw": arcade.load_spritesheet("Player_Throw.png", 70, 136, 3, 3)}
enemy_stats = {"Hp": 10, "Mana_Regen": 0.022, "Throw_Sound": "Archer_Throwsound.wav", "Partner": "ARCHER", "AI": "HOARDER"}

archer2_info = {"deck": enemy_deck, "textures": enemy_textures, "stats": enemy_stats}
enemy_list["Enemy9"] = archer2_info


chef_deck = ["BOWL", "BOWL", "BOWL", "SHIELD"]
chef_textures = {"Idle": arcade.load_spritesheet("Chef_Idle.png", 50, 155, 4, 8),
                   "Throw": arcade.load_spritesheet("Chef_Throw.png", 70, 155, 4, 4)}
chef_stats = {"Hp": 20, "Mana_Regen": 0.020, "Throw_Sound": "Player_Throwsound.wav", "Partner": None, "AI": "LATEGAME"}

chef2_info = {"deck": chef_deck, "textures": chef_textures, "stats": chef_stats}
enemy_list["Enemy10"] = chef2_info



enemy_deck = ["KUNAI", "SHURIKEN", "KATANA", "KATANA"]
enemy_textures = {"Idle": arcade.load_spritesheet("Ninja_Idle.png", 50, 136, 7, 14),
                   "Throw": arcade.load_spritesheet("Ninja_Throw.png", 70, 136, 3, 3)}
enemy_stats = {"Hp": 20, "Mana_Regen": 0.020, "Throw_Sound": "Player_Throwsound.wav", "Partner": "CLOWN", "AI": "LATEGAME"}

ninja1_info = {"deck": enemy_deck, "textures": enemy_textures, "stats": enemy_stats}
enemy_list["Enemy11"] = ninja1_info



enemy_order = list(enemy_list.keys())








cleric_info = {"Cooldown": 1800,
               "Idle": [arcade.load_spritesheet("Player_Idle_Mirrored.png", 50, 136, 7, 14),arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14)],
               "Skill": [arcade.load_spritesheet("Player_Idle_Mirrored.png", 50, 136, 7, 14),arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14)],
               }
archer_info = {"Cooldown": 900,
               "Idle": [arcade.load_spritesheet("Player_Idle_Mirrored.png", 50, 136, 7, 14),arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14)],
               "Skill": [arcade.load_spritesheet("Player_Idle_Mirrored.png", 50, 136, 7, 14),arcade.load_spritesheet("Player_Idle.png", 50, 136, 7, 14)],
               }
clown_info = {"Cooldown": 500,
               "Idle": [arcade.load_spritesheet("Clown_Idle_Mirrored.png", 50, 150, 2, 6),arcade.load_spritesheet("Clown_Idle.png", 50, 150, 2, 6)],
               "Skill": [arcade.load_spritesheet("Clown_Idle_Mirrored.png", 50, 150, 2, 6),arcade.load_spritesheet("Clown_Idle.png", 50, 150, 2, 6)],
               }

partner_list = {"CLERIC": cleric_info, "ARCHER": archer_info, "CLOWN": clown_info}

