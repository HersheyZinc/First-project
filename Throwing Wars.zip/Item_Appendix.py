#texture , dmg, hp, spd, mana, rotation, hit_sound, special
import arcade
Boing = arcade.load_sound("Boing.wav")
Wood = arcade.load_sound("Wood_hit.wav")
Hammer = arcade.load_sound("Hammer_Hit.wav")
Explosion = arcade.load_sound("Explosion.wav")
item_dict = {
    "CRATE": ("Wooden_Crate.png", 1, 3, 2, 1, 5, Wood, None),
    "ARROW": ("Arrow.png", 2, 1, 3, 1, 0, Boing, None),
    "HAMMER": ("Hammer.png", 2, 2, 2, 1, 5, Boing, None),
    "KNIFE": ("Knife.png", 2, 3, 2, 2, 8, Boing, None),
    "KUNAI": ("Kunai.png", 3, 1, 3, 2, 0, Boing, "STEALTH"),
    "SHIELD": ("Shield.png", 1, 12, 1, 3, 0, Hammer, None),
    "SWORD": ("Sword.png", 3, 3, 2, 3, 8, Boing, None),
    "SHURIKEN": ("Shuriken.png", 4, 2, 5, 3, 10, Boing, None),
    "SAWBLADE": ("Sawblade.png", 6, 2, 2, 3, 20, Boing, None),
    "KATANA": ("Katana.png", 2, 7, 3, 4, 5, Boing, None),
    "MULTISHOT": ("MultiShot.png", 3, 2, 2, 5, 10, Hammer, "MULTISHOT"),
    "CANNONBALL": ("Cannonball.png", 4, 6, 2, 4, 10, Hammer, None),
    "MISSILE": ("Missile.png", 6, 1, 2, 5, 0, Explosion, "EXPLODE"),

    "BIGSHIELD": ("Shield.png", 3, 30, 0.5, 9, 0, Hammer, "MASSIVE"),

    "BALL": ("Ball.png", 1, 3, 2, 1, 3, Boing, None),
    "DISGUISE": ("Fake_Disguise.png", 1, 6, 3, 2, 8, Boing, None),
    "JUGGLINGPIN": ("Juggling_Pin.png", 2, 3, 2, 6, 8, Boing, "MULTISHOT"),
    "JUGGLINGBALL": ("Juggling_Ball.png", 2, 1, 3, 3, 5, Boing, "MULTISHOT"),

    "BOWL": ("Bowl.png", 1, 3, 1, 0, 5, Boing, None),
    "CUP": ("Cup.png", 2, 2, 2, 1, 5, Boing, None),
    "FISH": ("Fish.png", 1, 2, 4, 1, 4, Boing, None),
    "STEAK": ("Steak.png", 1, 8, 1, 1, 7, Boing, None),


    "CHAINBOLA": ("Chain_Bola.png", 20, 99, 5, 0, 20, Boing, None),
    "BARRIER": ("Barrier.png", 7, 1, 0, 4, 0, Boing, "GROW"),
    "EXPLOSION": ("Smoke.png", 6, 1, 0, 4, 0, Explosion, "EXPLOSION")

}

usable_dict = {

    "CRATE": ("Wooden_Crate.png", 1, 3, 2, 1, 5, Wood, None),
    "ARROW": ("Arrow.png", 2, 1, 3, 1, 0, Boing, None),
    "HAMMER": ("Hammer.png", 2, 2, 2, 1, 5, Boing, None),
    "KNIFE": ("Knife.png", 2, 3, 2, 2, 8, Boing, None),
    "KUNAI": ("Kunai.png", 3, 1, 3, 2, 0, Boing, "STEALTH"),
    "SHIELD": ("Shield.png", 1, 12, 1, 3, 0, Hammer, None),
    "SWORD": ("Sword.png", 3, 3, 2, 3, 8, Boing, None),
    "SHURIKEN": ("Shuriken.png", 4, 2, 5, 3, 10, Boing, None),
    "SAWBLADE": ("Sawblade.png", 6, 2, 2, 3, 20, Boing, None),
    "KATANA": ("Katana.png", 2, 7, 3, 4, 5, Boing, None),
    "MULTISHOT": ("MultiShot.png", 3, 2, 2, 5, 10, Hammer, "MULTISHOT"),
    "CANNONBALL": ("Cannonball.png", 4, 5, 2, 4, 10, Hammer, None),
    "MISSILE": ("Missile.png", 6, 1, 2, 5, 0, Explosion, "EXPLODE")


}