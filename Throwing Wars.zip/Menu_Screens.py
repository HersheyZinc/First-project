import arcade


class VictoryView(arcade.View):
    def __init__(self):
        super().__init__()
        arcade.set_background_color(arcade.color.DARK_SPRING_GREEN)
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)
        nextlvl_button = Main_Button(self, x=SCREEN_WIDTH/2, y=SCREEN_HEIGHT *3/5, theme=self.theme,
                                            text="Next level", task="NEXT_LVL",
                                            width=300, height=50)
        self.button_list.append(nextlvl_button)
        main_menu_button = Main_Button(self, x=SCREEN_WIDTH / 2, y=SCREEN_HEIGHT * 3 / 5 - 80, theme=self.theme,
                                          text="Main Menu", task="MENU",
                                          width=300, height=50)
        self.button_list.append(main_menu_button)



    def on_draw(self):
        arcade.start_render()
        super().on_draw()

        arcade.draw_text("VICTORY!", SCREEN_WIDTH / 2, SCREEN_HEIGHT * 3 / 4,
                         arcade.color.YELLOW_ROSE, font_size=40, anchor_x="center", anchor_y="center",
                         bold=True)
        w, h = arcade.load_texture("Coin.png").width, arcade.load_texture("Coin.png").height
        arcade.draw_lrwh_rectangle_textured(0, SCREEN_HEIGHT - h, w, h, arcade.load_texture("Coin.png"))
        arcade.draw_text(f"{game_info[1]}", w + 10, SCREEN_HEIGHT - h / 2, arcade.color.BLACK, font_size=30, anchor_x="left",
                         anchor_y="center")
class DefeatView(arcade.View):
    def __init__(self):
        super().__init__()
        arcade.set_background_color(arcade.color.BLACK_BEAN)
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)
        nextlvl_button = Main_Button(self, x=SCREEN_WIDTH / 2, y=SCREEN_HEIGHT * 3 / 5, theme=self.theme,
                                     text="Retry", task="QUICKPLAY",
                                     width=300, height=50)
        self.button_list.append(nextlvl_button)
        main_menu_button = Main_Button(self, x=SCREEN_WIDTH / 2, y=SCREEN_HEIGHT * 3 / 5 - 80, theme=self.theme,
                                       text="Main Menu", task="MENU",
                                       width=300, height=50)
        self.button_list.append(main_menu_button)



    def on_draw(self):
        arcade.start_render()
        super().on_draw()

        arcade.draw_text("DEFEAT...", SCREEN_WIDTH / 2, SCREEN_HEIGHT * 3 / 4,
                         arcade.color.CRIMSON, font_size=40, anchor_x="center", anchor_y="center",
                         bold=True)
        w, h = arcade.load_texture("Coin.png").width, arcade.load_texture("Coin.png").height
        arcade.draw_lrwh_rectangle_textured(0, SCREEN_HEIGHT - h, w, h, arcade.load_texture("Coin.png"))
        arcade.draw_text(f"{game_info[1]}", w + 10, SCREEN_HEIGHT - h / 2, arcade.color.BLACK, font_size=30, anchor_x="left",
                         anchor_y="center")
class MenuView(arcade.View):
    def __init__(self):
        super().__init__()
        arcade.set_background_color(arcade.color.AUROMETALSAURUS)
        #self.mouse = arcade.Sprite("Mouse_Hitbox.png", scale=0.5)
        #self.mouse.alpha = 0
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)
        self.font_size = 40
        self.font_change = lambda ticks: 5*math.sin(0.1*ticks) + 40
        self.font_ticks = 0

    def setup(self):
        self.quickplay_button = Main_Button(self, x=SCREEN_WIDTH/2, y=SCREEN_HEIGHT *3/5, theme=self.theme,
                                            text=f"Quickplay - lvl {game_info[0] + 1}", task="QUICKPLAY",
                                            width=300, height=50)
        self.button_list.append(self.quickplay_button)
        edit_button = Main_Button(self, x=SCREEN_WIDTH/2, y=SCREEN_HEIGHT *3/5 - 70, theme=self.theme,
                                            text="Edit Deck", task="EDIT",
                                            width=300, height=50)
        self.button_list.append(edit_button)
        x, y = self.quickplay_button.center_x + self.quickplay_button.width/2, self.quickplay_button.center_y
        inc_lvl_button = Toggle_Button(self, width=50, height=self.quickplay_button.height/2, theme=self.theme, text="+", task="LVL+1")
        inc_lvl_button.center_x, inc_lvl_button.center_y = x + inc_lvl_button.width/2, y + inc_lvl_button.height/2
        self.button_list.append(inc_lvl_button)
        dec_lvl_button = Toggle_Button(self, width=50, height=self.quickplay_button.height / 2, theme=self.theme, text="-",task="LVL-1")
        dec_lvl_button.center_x, dec_lvl_button.center_y = x + dec_lvl_button.width / 2, y - dec_lvl_button.height / 2
        self.button_list.append(dec_lvl_button)

    def on_draw(self):
        arcade.start_render()
        #self.mouse.draw()
        super().on_draw()

        arcade.draw_text("Throwing Wars", SCREEN_WIDTH/2, SCREEN_HEIGHT * 3/4,
                         arcade.color.YELLOW_ROSE, font_size=self.font_size, anchor_x="center", anchor_y="center", bold=True)
        w, h = arcade.load_texture("Coin.png").width, arcade.load_texture("Coin.png").height
        arcade.draw_lrwh_rectangle_textured(0, SCREEN_HEIGHT - h, w, h, arcade.load_texture("Coin.png"))
        arcade.draw_text(f"{game_info[1]}",w+10,SCREEN_HEIGHT-h/2, arcade.color.BLACK, font_size=30, anchor_x="left", anchor_y="center")

    def update(self, delta_time=float):
        self.font_ticks += 0.8
        self.font_size = self.font_change(self.font_ticks)

class Edit_Deck(arcade.View):
    def __init__(self):
        super().__init__()
        self.theme = arcade.Theme()
        self.theme.set_font(25, arcade.color.WHITE_SMOKE)
        normal = "Button_GUI.png"
        self.theme.add_button_textures(normal)

        self.inventory_theme = arcade.Theme()
        self.inventory_theme.set_font(10, arcade.color.RICH_BLACK)
        normal = "Inventory_Bar_GUI.png"
        self.inventory_theme.add_button_textures(normal)

        self.GUI_list = arcade.SpriteList()
        self.inventory_list = []
        self.ammo_list = []

        self.create_inventory_GUI()

        border = GUI(arcade.load_texture("Edit_Deck_GUI.png"))
        border.position = SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2
        self.GUI_list.append(border)

        add_button = Toggle_Button(self, SCREEN_WIDTH * 0.9, SCREEN_HEIGHT/2 + 53, 77, 30, "+", self.theme, "ADD_AMMO")
        self.button_list.append(add_button)
        remove_button = Toggle_Button(self, SCREEN_WIDTH * 0.9, SCREEN_HEIGHT / 2 - 53, 77, 30, "-", self.theme,"REMOVE_AMMO")
        self.button_list.append(remove_button)
        item_slot = arcade.Sprite("Ammo_Selected.png", center_x=SCREEN_WIDTH * 0.9, center_y= SCREEN_HEIGHT/2)
        self.GUI_list.append(item_slot)

        self.item_selected = arcade.Sprite(self.inventory_list[0].texture, center_x=SCREEN_WIDTH * 0.9, center_y= SCREEN_HEIGHT/2, scale=0.9)
        self.GUI_list.append(self.item_selected)
        self.item_selected.type = self.inventory_list[0].type

        menu_button = Main_Button(self, SCREEN_WIDTH * 0.11, 50, 200, 40, "Main Menu", self.theme, "MENU")
        self.button_list.append(menu_button)
        save_deck_button = Toggle_Button(self, SCREEN_WIDTH * 0.11, 100, 200, 40, "Save deck", self.theme, "SAVE_DECK")
        self.button_list.append(save_deck_button)
        reload_deck_button = Toggle_Button(self, SCREEN_WIDTH * 0.11, 150, 200, 40, "Reset deck", self.theme, "RELOAD_DECK")
        self.button_list.append(reload_deck_button)
    def reset_inventory_GUI(self):
        for obj in self.inventory_list:
            obj.center_y = obj.min_y
            if obj.type != None:
                obj.count = temp_player_info.get("deck").count(obj.type)
                obj.text = "ATK:%s  HP:%s  " \
                           "SPD:%s  MANA:%s                COUNT:%s" % (obj.dmg, obj.hp, obj.spd, obj.mana, obj.count)

    def create_inventory_GUI(self):
        for y, obj in enumerate(player_dict):
            count = temp_player_info.get("deck").count(obj)
            stats = player_dict.get(obj)
            texture, dmg, hp ,spd, mana= stats[0], stats[1], stats[2], stats[3], stats[4]
            item_button = Toggle_Button(self, SCREEN_WIDTH/2, SCREEN_HEIGHT - 70 - y*52, 500, 52,
                                        "ATK:%s  HP:%s  "
                                        "SPD:%s  MANA:%s                COUNT:%s"%(dmg, hp, spd, mana, count),
                                        self.inventory_theme, "SELECT")
            item_button.min_y, item_button.max_y = item_button.center_y, item_button.center_y + len(player_dict) * item_button.height - 512
            item_button.type, item_button.texture, item_button.dmg, item_button.hp, item_button.spd, item_button.mana , item_button.count = obj, texture, dmg, hp ,spd, mana, count
            self.button_list.append(item_button)
            self.inventory_list.append(item_button)
            self.ammo_list.append(item_button)

            item_icon = arcade.Sprite(texture)
            item_icon.position = item_button.center_x - item_button.width/2 + item_icon.width/2, item_button.center_y
            item_icon.scale, item_icon.type = 2/3, None
            item_icon.max_y, item_icon.min_y = item_button.max_y, item_button.min_y
            self.GUI_list.append(item_icon)
            self.inventory_list.append(item_icon)
    def save_deck(self):
        edited_deck = []
        for ammo in self.ammo_list:
            for count in range(ammo.count):
                edited_deck.append(ammo.type)
        temp_player_info["deck"] = edited_deck
        save_game()
        print("deck saved")
    def on_draw(self):
        arcade.start_render()
        super().on_draw()
        self.GUI_list.draw()

    def on_mouse_scroll(self, x: int, y: int, scroll_x: int, scroll_y: int):
        if scroll_y != 0:
            for obj in self.inventory_list:
                obj.center_y = max(min(obj.center_y - scroll_y * 30, obj.max_y), obj.min_y)



class Toggle_Button(arcade.TextButton):
    def __init__(self, game, x=0, y=0, width=1, height=1, text="TEXT", theme=None, task=None):
        super().__init__(x, y, width, height, text, theme=theme)
        self.game = game
        self.task = task

    def on_press(self):

        if self.task == "LVL+1":
            game_info[0] = min(len(enemy_order)-1, game_info[0] + 1)
            self.game.quickplay_button.text = f"Quickplay - lvl {game_info[0] + 1}"
        elif self.task == "LVL-1":
            game_info[0] = max(0, game_info[0]-1)
            self.game.quickplay_button.text = f"Quickplay - lvl {game_info[0] + 1}"
        elif self.task == "SELECT":
            self.game.item_selected.texture = arcade.load_texture(dict.get(self.type)[0])
            self.game.item_selected.type = self.type
        elif self.task == "ADD_AMMO" or self.task == "REMOVE_AMMO":
            for obj in self.game.ammo_list:
                if obj.type == self.game.item_selected.type:
                    if self.task == "ADD_AMMO":
                        obj.count += 1
                    elif self.task == "REMOVE_AMMO":
                        obj.count = max(0, obj.count - 1)
                    obj.text = "ATK:%s  HP:%s  "\
                               "SPD:%s  MANA:%s                COUNT:%s"%(obj.dmg, obj.hp, obj.spd, obj.mana, obj.count)
                    break
        elif self.task == "SAVE_DECK":
            self.game.save_deck()
        elif self.task == "RELOAD_DECK":
            self.game.reset_inventory_GUI()






class Main_Button(arcade.TextButton):
    def __init__(self, game, x=SCREEN_WIDTH/2, y=500, width=300, height=50, text="TEXT", theme=None, task=None):
        super().__init__(x, y, width, height, text, theme=theme)
        self.game = game
        self.task = task


    def on_press(self):
        if self.task == "QUICKPLAY":
            enemy_chosen = enemy_order[game_info[0]]
            game_view = FightView(enemy_chosen)
            game_view.setup()
            window.show_view(game_view)
        elif self.task == "NEXT_LVL":
            game_info[0] = min(len(enemy_order)-1, game_info[0] + 1)
            enemy_chosen = enemy_order[game_info[0]]
            game_view = FightView(enemy_chosen)
            game_view.setup()
            window.show_view(game_view)
        elif self.task == "MENU":
            menu_view = MenuView()
            menu_view.setup()
            window.show_view(menu_view)
        elif self.task == "EDIT":
            edit_view = Edit_Deck()
            window.show_view(edit_view)
        elif  self.task == "SAVE":
            save_game()