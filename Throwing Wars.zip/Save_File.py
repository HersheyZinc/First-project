import arcade

money = 569
player_deck = ['CRATE', 'CRATE', 'CRATE', 'CRATE', 'ARROW', 'HAMMER', 'HAMMER', 'HAMMER', 'HAMMER', 'KNIFE', 'KNIFE', 'KNIFE', 'SHIELD', 'SHIELD', 'SHIELD', 'SHIELD', 'SWORD', 'SWORD', 'CANNONBALL', 'CANNONBALL']
player_textures = {"Idle":arcade.load_spritesheet("Player_Idle_Mirrored.png", 50, 136, 7, 14),
                   "Throw":arcade.load_spritesheet("Player_Throw_Mirrored.png", 70, 136, 3, 3)}
player_stats = {"Hp": 20, "Mana_Regen": 0.02, "Throw_Sound": "Player_Throwsound.wav", "Partner": "ARCHER"}

player_info = {"deck": player_deck, "textures": player_textures, "stats": player_stats}